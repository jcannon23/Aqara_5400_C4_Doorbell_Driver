-- Legacy-unicast mDNS query: multicast IPv4 request, ephemeral source port.
-- Discovers AAAA records without requiring an IPv6 multicast interface index.
do
  local function say(s) print('[Aqara Discovery v6] '..s) end
  local function safe(s) return (tostring(s):gsub('[^%w ._:=%+%-]','?')):sub(1,240) end
  if AqaraDiscoveryRunning then say('Already running'); return end
  say('BEGIN - read-only DNS-SD; no commissioning')
  local ok,socket=pcall(require,'socket')
  if not ok then ok,socket=pcall(require,'socket.core') end
  if not ok or type(socket)~='table' then say('LuaSocket unavailable'); say('END'); return end
  local s,timers,done=nil,{},false
  local function cleanup()
    if done then return end; done=true
    for _,t in ipairs(timers) do pcall(function() t:Cancel() end) end
    if s then pcall(function() s:close() end) end
    AqaraDiscoveryRunning=nil
  end
  local ran=pcall(function()
    s=assert((socket.udp4 or socket.udp)())
    assert(s:settimeout(0)); assert(s:setsockname('*',0))
    assert(s:setoption('ip-multicast-ttl',255))
    AqaraDiscoveryRunning=true
    local id=41990
    local requested,seen,instances,hosts={},{},{},{}
    local sends,received,printed,invalid=0,0,0,0
    local function query(name,kind)
      local key=name..':'..kind
      if requested[key] or sends>=24 then return end
      requested[key]=true; sends=sends+1
      local sent,err=s:sendto(DNS.query(id,name,kind),'224.0.0.251',5353)
      if not sent then say('Query send error: '..safe(err)) end
    end
    local function show(line)
      if not seen[line] and printed<64 then seen[line]=true; printed=printed+1; say(line) end
    end
    local function process(response)
      -- Establish relevance before printing, regardless of record order.
      for _,r in ipairs(response.records) do
        if r.class==1 and r.ttl>0 and r.kind==12 and
          (r.name=='_matter._tcp.local' or r.name=='_matterc._udp.local') then
          instances[r.target]=true
          show('SERVICE '..safe(r.name)..' -> '..safe(r.target))
          query(r.target,33); query(r.target,16)
        end
      end
      for _,r in ipairs(response.records) do
        if r.class==1 and r.ttl>0 and instances[r.name] then
          if r.kind==33 then
            hosts[r.target]=true
            show('SRV '..safe(r.name)..' host='..safe(r.target)..' port='..r.port)
            query(r.target,28); query(r.target,1)
          elseif r.kind==16 then
            -- Only documented discovery metadata; no arbitrary TXT dump.
            for _,text in ipairs(r.txt) do
              local key=text:match('^([^=]+)=')
              if key=='D' or key=='VP' or key=='CM' or key=='DN' or key=='DT' then
                show('TXT '..safe(r.name)..' '..safe(text))
              end
            end
          end
        end
      end
      for _,r in ipairs(response.records) do
        if r.class==1 and r.ttl>0 and hosts[r.name] and r.address then
          show((r.kind==28 and 'AAAA ' or 'A ')..safe(r.name)..' '..r.address)
        end
      end
    end
    timers[#timers+1]=assert(C4:SetTimer(10000,function()
      say('SUMMARY replies='..received..' records_printed='..printed..' invalid='..invalid..' queries='..sends)
      cleanup(); say('END - socket closed')
    end))
    query('_matter._tcp.local',12); query('_matterc._udp.local',12)
    timers[#timers+1]=assert(C4:SetTimer(100,function()
      if done then return end
      local success=pcall(function()
        for _=1,8 do
          if received>=128 then return end
          local packet,peer,port=s:receivefrom(4096)
          if not packet then break end
          received=received+1
          if port==5353 then
            local response=DNS.parse(packet)
            if response and response.id==id then process(response)
            elseif not response then invalid=invalid+1 end
          end
        end
      end)
      if not success then cleanup(); say('Receive/parse API error; socket closed'); say('END') end
    end,true))
  end)
  if not ran then cleanup(); say('Socket/timer setup error; socket closed'); say('END') end
end
