-- Generated standalone read-only discovery probe. Paste all into Composer Lua Command.
do
local DNS=(function()
-- Bounded read-only DNS codec for a discovery spike. RFC 1035 / RFC 6762.
local DNS={}
local function u16(n) return string.char(math.floor(n/256)%256,n%256) end
local function wireName(name)
  local out,total={},1
  for label in name:gmatch('[^.]+') do
    assert(#label<=63 and #label>0,'label length')
    total=total+#label+1; assert(total<=255,'name length')
    out[#out+1]=string.char(#label)..label
  end
  return table.concat(out)..'\0'
end
function DNS.query(id,name,kind)
  return u16(id)..u16(0)..u16(1)..u16(0)..u16(0)..u16(0)..wireName(name)..u16(kind)..u16(1)
end
function DNS.parse(packet)
  local ok,result=pcall(function()
    assert(type(packet)=='string' and #packet>=12 and #packet<=4096,'size')
    local function number(pos,width)
      assert(pos>=1 and pos+width-1<=#packet,'truncated')
      local n=0
      for i=pos,pos+width-1 do n=n*256+packet:byte(i) end
      return n
    end
    local function name(pos)
      local out,visited,nextPos,total={}, {},nil,1
      for _=1,128 do
        assert(not visited[pos],'pointer cycle'); visited[pos]=true
        local len=number(pos,1)
        if len==0 then return table.concat(out,'.'):lower(),nextPos or pos+1 end
        if len>=192 then
          nextPos=nextPos or pos+2
          pos=(len-192)*256+number(pos+1,1)+1
          assert(pos>=1 and pos<=#packet,'pointer range')
        else
          assert(len<=63,'invalid label')
          number(pos+len,1)
          total=total+len+1; assert(total<=255,'name length')
          out[#out+1]=packet:sub(pos+1,pos+len)
          pos=pos+len+1
        end
      end
      error('name depth')
    end
    local flags=number(3,2)
    assert(flags>=32768 and math.floor(flags/2048)%16==0 and flags%16==0,'not successful response')
    assert(math.floor(flags/512)%2==0,'truncated response')
    local questions=number(5,2)
    local count=number(7,2)+number(9,2)+number(11,2)
    assert(questions<=32 and count<=96,'record limit')
    local pos=13
    for _=1,questions do local ignored; ignored,pos=name(pos); number(pos,4); pos=pos+4 end
    local records={}
    for _=1,count do
      local owner; owner,pos=name(pos)
      local kind,class,ttl,length=number(pos,2),number(pos+2,2),number(pos+4,4),number(pos+8,2)
      pos=pos+10
      local stop=pos+length
      assert(stop<=#packet+1,'rdata bounds')
      local record={name=owner,kind=kind,class=class%32768,ttl=ttl}
      if kind==12 then
        local after; record.target,after=name(pos); assert(after==stop,'PTR length')
      elseif kind==33 then
        assert(length>=7,'SRV length'); record.port=number(pos+4,2)
        local after; record.target,after=name(pos+6); assert(after==stop,'SRV target length')
      elseif kind==16 then
        local p=pos; record.txt={}
        while p<stop do
          local len=number(p,1); p=p+1; assert(p+len<=stop,'TXT length')
          record.txt[#record.txt+1]=packet:sub(p,p+len-1); p=p+len
        end
      elseif kind==28 then
        assert(length==16,'AAAA length'); local groups={}
        for p=pos,pos+15,2 do groups[#groups+1]=string.format('%x',number(p,2)) end
        record.address=table.concat(groups,':')
      elseif kind==1 then
        assert(length==4,'A length'); local bytes={}
        for p=pos,pos+3 do bytes[#bytes+1]=tostring(number(p,1)) end
        record.address=table.concat(bytes,'.')
      end
      records[#records+1]=record; pos=stop
    end
    return {id=number(1,2),records=records}
  end)
  if not ok then return nil,'invalid or unsupported DNS response' end
  return result
end
return DNS

end)()
-- Legacy-unicast mDNS query: multicast IPv4 request, ephemeral source port.
-- Discovers AAAA records without requiring an IPv6 multicast interface index.
do
  local function say(s) print('[Aqara Discovery v6] '..s) end
  local function safe(s) return (tostring(s):gsub('[^%w ._:=%+%-]','?')):sub(1,240) end
  if AqaraDiscoveryRunning then say('Already running'); return end
  say('BEGIN - read-only DNS-SD; no commissioning')
  local ok,socket=pcall(require,'socket')
  if not ok then ok,socket=pcall(require,'socket.core') end
  if not ok or type(socket)~='table' then say('LuaSocket unavailable'); say('END'); return end
  local s,timers,done=nil,{},false
  local function cleanup()
    if done then return end; done=true
    for _,t in ipairs(timers) do pcall(function() t:Cancel() end) end
    if s then pcall(function() s:close() end) end
    AqaraDiscoveryRunning=nil
  end
  local ran=pcall(function()
    s=assert((socket.udp4 or socket.udp)())
    assert(s:settimeout(0)); assert(s:setsockname('*',0))
    assert(s:setoption('ip-multicast-ttl',255))
    AqaraDiscoveryRunning=true
    local id=41990
    local requested,seen,instances,hosts={},{},{},{}
    local sends,received,printed,invalid=0,0,0,0
    local function query(name,kind)
      local key=name..':'..kind
      if requested[key] or sends>=24 then return end
      requested[key]=true; sends=sends+1
      local sent,err=s:sendto(DNS.query(id,name,kind),'224.0.0.251',5353)
      if not sent then say('Query send error: '..safe(err)) end
    end
    local function show(line)
      if not seen[line] and printed<64 then seen[line]=true; printed=printed+1; say(line) end
    end
    local function process(response)
      -- Establish relevance before printing, regardless of record order.
      for _,r in ipairs(response.records) do
        if r.class==1 and r.ttl>0 and r.kind==12 and
          (r.name=='_matter._tcp.local' or r.name=='_matterc._udp.local') then
          instances[r.target]=true
          show('SERVICE '..safe(r.name)..' -> '..safe(r.target))
          query(r.target,33); query(r.target,16)
        end
      end
      for _,r in ipairs(response.records) do
        if r.class==1 and r.ttl>0 and instances[r.name] then
          if r.kind==33 then
            hosts[r.target]=true
            show('SRV '..safe(r.name)..' host='..safe(r.target)..' port='..r.port)
            query(r.target,28); query(r.target,1)
          elseif r.kind==16 then
            -- Only documented discovery metadata; no arbitrary TXT dump.
            for _,text in ipairs(r.txt) do
              local key=text:match('^([^=]+)=')
              if key=='D' or key=='VP' or key=='CM' or key=='DN' or key=='DT' then
                show('TXT '..safe(r.name)..' '..safe(text))
              end
            end
          end
        end
      end
      for _,r in ipairs(response.records) do
        if r.class==1 and r.ttl>0 and hosts[r.name] and r.address then
          show((r.kind==28 and 'AAAA ' or 'A ')..safe(r.name)..' '..r.address)
        end
      end
    end
    timers[#timers+1]=assert(C4:SetTimer(10000,function()
      say('SUMMARY replies='..received..' records_printed='..printed..' invalid='..invalid..' queries='..sends)
      cleanup(); say('END - socket closed')
    end))
    query('_matter._tcp.local',12); query('_matterc._udp.local',12)
    timers[#timers+1]=assert(C4:SetTimer(100,function()
      if done then return end
      local success=pcall(function()
        for _=1,8 do
          if received>=128 then return end
          local packet,peer,port=s:receivefrom(4096)
          if not packet then break end
          received=received+1
          if port==5353 then
            local response=DNS.parse(packet)
            if response and response.id==id then process(response)
            elseif not response then invalid=invalid+1 end
          end
        end
      end)
      if not success then cleanup(); say('Receive/parse API error; socket closed'); say('END') end
    end,true))
  end)
  if not ran then cleanup(); say('Socket/timer setup error; socket closed'); say('END') end
end

end
