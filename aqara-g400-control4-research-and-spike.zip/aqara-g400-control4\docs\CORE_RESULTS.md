# CORE 1 runtime evidence

User-supplied output, 2026-09-26. Director reports **4.0.0.734549-res**. The user successfully loaded the corrected feasibility driver and ran the v2 native probe.

| Check | Actual CORE result | Reported elapsed |
|---|---|---|
| Random API smoke check | PASS | 0 ms |
| AES-128-ECB known-answer, no padding | PASS | 2 ms |
| P-256 ECDH shared-secret agreement | PASS | 6 ms |
| P-256 ECDSA SHA256, altered-message rejection | PASS | 3 ms |
| BN arithmetic at P-256 field size | PASS | 0 ms |

These are single diagnostic observations, not a benchmark, entropy certification or constant-time assessment. They remove uncertainty about these exact operations on this controller. BN support does not establish a secure SPAKE2+ implementation.

## Next: CCM adapter test

Paste all of `tools/core-ccm-probe.lua` into the same Composer Lua Command pane and execute once. No driver update is required. Return the BEGIN-through-END output; expected summary is `RESULT 10/10 passed`.

The probe combines bounded Lua CCM formatting with native OpenSSL AES block encryption. It does not rely on direct OpenSSL CCM bindings. Test material is public, fixed and never used for real sessions. It makes no network requests, stores no data and fires no doorbell events.

Local validation: 92 assertions passed with Windows .NET AES, plus the bundled probe's 10 checks with that backend. **CORE CCM validation: user reports 10/10 PASS**, with each test taking 1-3 ms. Both encryption/decryption vectors and altered tag, ciphertext and AAD rejection passed. Vectors: [RFC 3610 packet 1](https://www.rfc-editor.org/rfc/rfc3610.html), and [CAVP CCM-VTT128 count 60, mirrored by pyca](https://github.com/pyca/cryptography/blob/main/vectors/cryptography_vectors/ciphers/AES/CCM/VTT128.rsp). The second vector checks a 13-byte nonce and 16-byte authentication tag.

The experimental adapter is not included in the live `.c4z`. It bounds plaintext/AAD to 1280 bytes each, is synchronous per operation, and has not received a security review. Tag comparison processes all tag bytes but no constant-time guarantee is made for Lua. Session nonce uniqueness, replay protection, credential durability and network transport are separate unimplemented responsibilities.

Remaining gates: C4 SHA256/HMAC probe results; IPv6 UDP/mDNS transport; vetted SPAKE2+ and HKDF/PBKDF2 adapters; certificates; PASE/CASE; commissioning; descriptor discovery and actual M100 Signal behavior.

## Transport v4 results

User reports exact IPv4 binary echo PASS and IPv6 NO ECHO through CreateNetworkConnection/NetConnect/SendToNetwork. The PC responder recorded the IPv4 packet from CORE at 192.168.1.136, but no IPv6 packet. Local IPv4/IPv6 responder self-tests passed. Matching Windows public-profile PowerShell UDP allow rules were present; no firewall rules were changed.

This isolates an IPv6-path issue, not its cause. Next diagnostic: `tools/core-ipv6-socket-probe.lua` checks LuaSocket availability, explicit udp6 loopback and LAN reachability with nonblocking sockets. [LuaSocket UDP documentation](https://lunarmodules.github.io/luasocket/udp.html). Control4's reference describes an ongoing move away from LuaSocket, so any successful use remains a compatibility consideration rather than a future support guarantee.

## Transport v5 results — native IPv6 confirmed

User reports LuaSocket 3.0.0 with `udp6` available, IPv6 loopback PASS and IPv6 LAN PASS. The source address reported by CORE is `fdb2:736a:697e:40e7:20f:ffff:fe9d:4e90`. The PC log independently records receipt and echo of the 61-byte IPv6 probe from that address.

This proves a working native IPv6 UDP route through LuaSocket on the actual CORE 1. The v4 failure is confined to the alternative C4 network API path as tested; it is not evidence of a general IPv6 failure. No external helper is needed for this transport test. Future OS support and production receive-loop performance still need review.

## Next: read-only Matter discovery

Paste `tools/core-discovery-probe.lua` into the same Composer Lua Command pane and execute. It ends after ten seconds. No PC responder, driver update, setup code or sharing mode is required for the first run. Return the BEGIN-through-END output.

The probe sends legacy-unicast mDNS queries for `_matter._tcp.local` and `_matterc._udp.local`, follows PTR/SRV/TXT/A/AAAA records, and limits follow-up requests, packet sizes, parsing work and printed output. Requests use IPv4 multicast and an ephemeral source port; responses can contain IPv6 addresses. It does not yet test IPv6 multicast membership or implement a persistent discovery cache. Devices that are not in a commissioning window may advertise only their operational service.

A result is a discovery candidate, not proof it is the user's M100. Service records describe Matter nodes; bridged Signal endpoint discovery requires a commissioned authenticated session. No-result output is inconclusive: multicast filtering, interface selection and advertiser behavior still need checking.

References: [official Matter discovery guide](https://project-chip.github.io/connectedhomeip-doc/tips_and_troubleshooting/discovery_from_a_host_computer.html), [RFC 6762](https://www.rfc-editor.org/rfc/rfc6762.html). Local tests: 266 DNS assertions and bundled-probe timeout/cleanup checks passed. CORE discovery results are recorded below.


## Discovery v6 results

CORE returned 94 replies, 62 printed records, zero invalid packets and 24 queries. Operational Matter services, SRV ports and IPv4/IPv6 addresses were discovered. No commissionable service was printed. The 24-query limit was reached, so this is not a complete inventory or proof that no commissioning window existed.

This validates the diagnostic legacy-unicast DNS-SD path on CORE. It does not identify the M100 conclusively or discover its bridged Signal endpoints. Next: confirm the M100 identity and run focused commissionable discovery during a fresh multi-admin sharing window. SPAKE2+, PASE/CASE, credential persistence and subscription behavior remain unvalidated.
