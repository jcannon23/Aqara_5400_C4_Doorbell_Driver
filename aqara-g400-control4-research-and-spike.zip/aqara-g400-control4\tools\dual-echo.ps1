param([int]$Port=55491,[int]$Seconds=600)
$ErrorActionPreference='Stop'
if($Port -lt 1024 -or $Port -gt 65535 -or $Seconds -lt 1 -or $Seconds -gt 600){throw 'Invalid limits'}
$udp=New-Object System.Net.Sockets.UdpClient([System.Net.Sockets.AddressFamily]::InterNetworkV6)
try {
  $udp.Client.DualMode=$true
  $udp.Client.Bind((New-Object System.Net.IPEndPoint([System.Net.IPAddress]::IPv6Any,$Port)))
  $udp.Client.ReceiveTimeout=1000
  $deadline=[DateTime]::UtcNow.AddSeconds($Seconds)
  Write-Output "START dual-stack UDP echo port=$Port until=$($deadline.ToString('o'))"
  while([DateTime]::UtcNow -lt $deadline){
    $peer=New-Object System.Net.IPEndPoint([System.Net.IPAddress]::IPv6Any,0)
    try{$bytes=$udp.Receive([ref]$peer)}
    catch [System.Net.Sockets.SocketException]{
      if($_.Exception.SocketErrorCode -eq [System.Net.Sockets.SocketError]::TimedOut){continue}; throw
    }
    $text=[System.Text.Encoding]::ASCII.GetString($bytes)
    if($bytes.Length -le 128 -and $text.StartsWith('AQARA-NET4:')){
      [void]$udp.Send($bytes,$bytes.Length,$peer)
      $kind=if($text.Contains('SELFTEST')){'SELFTEST'}else{'CORE-PROBE'}
      Write-Output "$([DateTime]::UtcNow.ToString('o')) $kind peer=$peer bytes=$($bytes.Length) echoed"
    }
  }
  Write-Output 'STOP deadline reached'
} finally {$udp.Dispose()}
