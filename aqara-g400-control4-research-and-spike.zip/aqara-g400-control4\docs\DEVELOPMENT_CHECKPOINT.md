# Development checkpoint — 2026-09-26

## Objective and status

Receive the Aqara G400 doorbell Signal bridged through M100 entirely on Control4 CORE 1, then fire a native Doorbell Pressed event. The implementation is a diagnostic prototype. It cannot yet commission M100 or receive physical doorbell presses.

The original requirements are preserved in ORIGINAL_HANDOFF.md as design context; they are not evidence of implemented functionality.

## Hardware evidence

CORE runs Director 4.0.0.734549-res and LuaSocket 3.0.0. User-run probes confirmed AES ECB known-answer, P-256 ECDH agreement, ECDSA signing/verification and altered-message rejection, BN arithmetic, and ten CCM vector/tamper checks. Random API availability was smoke-tested, not entropy-certified.

C4 network API IPv4 echo passed while its tested IPv6 path did not. LuaSocket udp6 loopback and LAN echo both passed. Read-only DNS-SD v6 discovered operational services: 94 replies, 62 printed records, zero invalid packets, 24 queries. Query cap reached; no commissionable service printed. M100 identity is not confirmed.

## Code map

- driver/: diagnostic event source, debounce, runtime checks and persistence canary.
- experimental/: bounded CCM adapter and DNS parser, plus standalone probe bodies.
- tools/: generated paste-and-run Composer Lua probes and temporary PC echo responders.
- tests/: Lua tests, public CCM vectors and Windows Lua 5.1 runner.
- build/: diagnostic c4z; build.ps1 rebuilds it.
- build-ccm-probe.ps1 and build-discovery-probe.ps1: regenerate standalone probes.

Standalone probes are not integrated into the packaged driver. Composer indexing required combo metadata and matching proxy filename identity; the version 2 package was successfully loaded by the user.

## Next work

1. Confirm M100 identity; perform focused commissionable discovery in a fresh multi-admin sharing window.
2. Validate SHA256/HMAC and implement/test HKDF/PBKDF2 and a vetted SPAKE2+ path with acceptable Director latency.
3. Implement authenticated commissioning/session handling and durable credentials; verify restart recovery.
4. Discover bridged endpoints, identify the actual Signal representation, subscribe and validate physical button events.

PASE, CASE, certificate lifecycle, replay protection, subscriptions and real doorbell behavior remain unimplemented. Primitive tests do not establish a secure Matter controller.

## Preservation

Keep source, build scripts, tests, generated probes, diagnostic c4z and research docs together. Local test results and hardware observations are described in CORE_RESULTS.md and VALIDATION.md. No production Matter credentials have been created. Echo probes currently contain site-specific LAN addresses; configure these for a different test network. Raw discovery inventories are not needed for the public code history.
