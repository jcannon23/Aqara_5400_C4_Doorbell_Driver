-- Test diagnostic control flow only; this does not emulate real crypto.
local checks = 0
local function check(value) assert(value); checks = checks + 1 end
local function run(module, timersAvailable)
  local output, pending = {}, {}
  local env = setmetatable({
    print=function(line) output[#output+1]=line end,
    require=function() if module == false then error('SECRET ERROR PAYLOAD') end; return module end,
    C4={
      GetVersionInfo=function() return {version='4.0.0'} end,
      GetTickCount=function() return 10 end,
      SetTimer=function(_,delay,cb)
        if not timersAvailable then error('SECRET ERROR PAYLOAD') end
        pending[#pending+1]=cb; return {}
      end,
    },
  },{__index=_G})
  local chunk=assert(loadfile('tools/core-native-probe.lua'))
  setfenv(chunk,env); chunk()
  local i=1
  while pending[i] do pending[i](); i=i+1; assert(i<10) end
  return table.concat(output,'\n'), #pending
end
local output=run(false,true)
check(output:find('OpenSSL: UNAVAILABLE'))
check(not output:find('SECRET'))
local count
output,count=run({},true)
local _, failures=output:gsub('API ERROR / UNSUPPORTED','')
check(failures==5)
check(count==4)
check(output:find('END %- share'))
check(not output:find('SECRET'))
output=run({},false)
check(output:find('STOP: timer unavailable'))
check(not output:find('SECRET'))
print('PASS: '..checks..' native-probe control-flow assertions; actual crypto remains untested.')
