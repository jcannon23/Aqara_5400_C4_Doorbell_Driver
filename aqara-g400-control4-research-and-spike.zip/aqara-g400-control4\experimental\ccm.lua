-- Experimental bounded AES-CCM composition, RFC 3610 sections 2.2-2.5.
-- Caller supplies native AES-128 block encryption; no AES implementation here.
-- Not wired to the driver. Nonce uniqueness/replay protection belong to sessions.
local CCM = {}
local LIMIT = 1280
local function xorByte(a, b)
  local out, bit = 0, 1
  for _ = 1, 8 do
    out = out + ((a % 2 + b % 2) % 2) * bit
    a = math.floor(a / 2); b = math.floor(b / 2); bit = bit * 2
  end
  return out
end
local function xor(a, b)
  local out = {}
  for i = 1, #a do out[i] = string.char(xorByte(a:byte(i), b:byte(i))) end
  return table.concat(out)
end
local function be(n, width)
  local out = {}
  for i = width, 1, -1 do out[i] = string.char(n % 256); n = math.floor(n / 256) end
  return table.concat(out)
end
local function pad(data) return data .. string.rep('\0', (16 - #data % 16) % 16) end
local function valid(key, nonce, aad, data, tagLength)
  return type(key) == 'string' and #key == 16 and type(nonce) == 'string' and
    #nonce >= 7 and #nonce <= 13 and type(aad) == 'string' and #aad <= LIMIT and
    type(data) == 'string' and #data <= LIMIT and type(tagLength) == 'number' and
    tagLength >= 4 and tagLength <= 16 and tagLength % 2 == 0
end
local function cipher(aes, key)
  return function(block)
    local result = aes(key, block)
    if type(result) ~= 'string' or #result ~= 16 then error('AES block failure') end
    return result
  end
end
local function mac(enc, nonce, aad, plaintext, tagLength)
  local width = 15 - #nonce
  local flags = (#aad > 0 and 64 or 0) + (tagLength - 2) * 4 + width - 1
  local state = enc(string.char(flags) .. nonce .. be(#plaintext, width))
  local function feed(data)
    data = pad(data)
    for i = 1, #data, 16 do state = enc(xor(state, data:sub(i, i+15))) end
  end
  -- Bounded AAD uses the RFC's two-byte length form (< 65280).
  if #aad > 0 then feed(be(#aad, 2) .. aad) end
  feed(plaintext)
  return state:sub(1, tagLength)
end
local function stream(enc, nonce, data)
  local width, out = 15 - #nonce, {}
  local prefix = string.char(width - 1) .. nonce
  for i = 1, #data, 16 do
    out[#out+1] = xor(data:sub(i,i+15), enc(prefix .. be((i-1)/16+1, width)))
  end
  return table.concat(out), enc(prefix .. be(0, width))
end
function CCM.encrypt(aes, key, nonce, aad, plaintext, tagLength)
  if type(aes) ~= 'function' or not valid(key,nonce,aad,plaintext,tagLength) then return nil, 'invalid input' end
  local ok, output = pcall(function()
    local enc = cipher(aes,key)
    local ciphertext, mask = stream(enc,nonce,plaintext)
    return ciphertext .. xor(mac(enc,nonce,aad,plaintext,tagLength), mask)
  end)
  if not ok then return nil, 'crypto failure' end
  return output
end
function CCM.decrypt(aes, key, nonce, aad, packet, tagLength)
  if type(packet) ~= 'string' or type(tagLength) ~= 'number' or tagLength % 2 ~= 0 or
      tagLength < 4 or tagLength > 16 or #packet < tagLength or #packet > LIMIT + tagLength then
    return nil, 'invalid input'
  end
  local ciphertext = packet:sub(1, #packet-tagLength)
  if type(aes) ~= 'function' or not valid(key,nonce,aad,ciphertext,tagLength) then return nil, 'invalid input' end
  local ok, plaintext = pcall(function()
    local enc = cipher(aes,key)
    local candidate, mask = stream(enc,nonce,ciphertext)
    local expected = xor(mac(enc,nonce,aad,candidate,tagLength), mask)
    local supplied = packet:sub(#packet-tagLength+1)
    -- Compare all bytes; no early-exit comparison. Lua execution is not claimed constant-time.
    local diff = 0
    for i = 1, tagLength do diff = diff + xorByte(expected:byte(i), supplied:byte(i)) end
    if diff ~= 0 then return nil end
    return candidate -- Never return unauthenticated plaintext.
  end)
  if not ok then return nil, 'crypto failure' end
  if plaintext == nil then return nil, 'authentication failed' end
  return plaintext
end
return CCM
