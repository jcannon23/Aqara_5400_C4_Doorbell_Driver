param([Parameter(Mandatory=$true)][string]$ScriptPath)
$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
public static class LuaSpikeRunner {
 const string Dll = @"C:\Program Files (x86)\Control4\Shared\4.0.0\Director\lua51.dll";
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern IntPtr luaL_newstate();
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern void luaL_openlibs(IntPtr state);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern int luaL_loadfile(IntPtr state, string name);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern int lua_pcall(IntPtr state,int args,int results,int err);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern IntPtr lua_tolstring(IntPtr state,int index,IntPtr len);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern void lua_close(IntPtr state);
 [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int LuaFunction(IntPtr state);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern void lua_pushcclosure(IntPtr state, LuaFunction fn, int n);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern void lua_setfield(IntPtr state, int idx, string name);
 [DllImport(Dll, CallingConvention=CallingConvention.Cdecl)] public static extern void lua_pushlstring(IntPtr state, byte[] value, UIntPtr size);
 public static LuaFunction Root = Encrypt;
 public static void Register(IntPtr state) { lua_pushcclosure(state,Root,0); lua_setfield(state,-10002,"TestAES"); }
 public static int Encrypt(IntPtr state) {
   byte[] key = new byte[16], input = new byte[16];
   Marshal.Copy(lua_tolstring(state,1,IntPtr.Zero),key,0,16);
   Marshal.Copy(lua_tolstring(state,2,IntPtr.Zero),input,0,16);
   using(Aes aes = Aes.Create()) {
     aes.Mode=CipherMode.ECB; aes.Padding=PaddingMode.None; aes.Key=key;
     using(ICryptoTransform transform = aes.CreateEncryptor()) {
       byte[] output=transform.TransformFinalBlock(input,0,16);
       lua_pushlstring(state,output,(UIntPtr)output.Length);
     }
   }
   return 1;
 }
}
'@
$state=[LuaSpikeRunner]::luaL_newstate()
if ($state -eq [IntPtr]::Zero) { throw 'No Lua state' }
try {
  [LuaSpikeRunner]::luaL_openlibs($state)
  [LuaSpikeRunner]::Register($state)
  $code=[LuaSpikeRunner]::luaL_loadfile($state,$ScriptPath)
  if ($code -eq 0) { $code=[LuaSpikeRunner]::lua_pcall($state,0,-1,0) }
  if ($code -ne 0) { throw [Runtime.InteropServices.Marshal]::PtrToStringAnsi([LuaSpikeRunner]::lua_tolstring($state,-1,[IntPtr]::Zero)) }
} finally { [LuaSpikeRunner]::lua_close($state) }
