# Aqara G400 Matter Doorbell — feasibility spike

**This is a diagnostic prototype, not a working Matter doorbell integration.** It cannot pair with M100 or receive physical G400 presses. The [revised feasibility assessment](FEASIBILITY.md) withdraws the initial NO-GO following evidence of a commercial native Control4 Matter driver. Our own implementation remains unverified. Reusable helper options remain fallbacks in [REUSE.md](docs/REUSE.md).

## Included

- `build/aqara_g400_matter_spike.c4z`: packaged diagnostic driver.
- `driver/`: readable Lua, XML and packaging manifest.
- Native `Doorbell Pressed` event and manual test action.
- Simulated state transitions with nonblocking debounce (3 seconds by default).
- Runtime capability probe, encrypted persistence canary and opt-in IPv6 UDP echo probe.
- Tests, build script, setup and validation instructions.

## Install and test the Control4 announcement path

1. Back up the Composer project. Copy the spike `.c4z` to your Composer driver directory and add **Aqara G400 Matter Doorbell - Feasibility Spike** to the project. It uses a different filename from the existing Aqara alpha driver.
2. In Programming, select this driver and its **Doorbell Pressed** event. Attach the existing **Front Doorbell Announcement** action.
3. In the driver's Actions tab, select **Test Doorbell Event**. This fires event ID 1 immediately and deliberately bypasses signal debounce. It can play your configured announcement.
4. To test edges: enable Debug Logging, run **Simulate Signal Inactive**, then **Simulate Signal Active**. Repeat active without inactive: no additional ring. Re-arm with inactive and wait at least 3 seconds before another activation. Disable logging afterward.

The first simulated report after restart is a baseline; an initial active value does not ring. The driver declares a combo identity matching its filename so Composer can index it; it uses no separate device proxy. Actual announcement playback remains unverified.

## Collect CORE 1 evidence

**Latest:** native crypto, CCM, LuaSocket IPv6 UDP and read-only Matter DNS-SD discovery passed on CORE 1. Discovery returned operational services; M100 identity and commissioning remain unverified. See [CORE results](docs/CORE_RESULTS.md) and [development checkpoint](docs/DEVELOPMENT_CHECKPOINT.md).

**Next step for confirmed OS 4.0.0:** follow [the native probe instructions](docs/NATIVE_NEXT_STEP.md). Paste `tools/core-native-probe.lua` into Composer's Lua Command pane to test actual cryptographic operations. This is separate from the packaged driver's original presence probe.

Run **Run Runtime Probe** and save the Lua Output or Runtime Diagnostics property. It prints only selected public capability results, not credentials. False/unavailable results from a missing API are diagnostic findings, not crashes.

Run **Write Persistence Canary**, allow the database write to settle, then perform a planned Director restart. Verify Persistence Check reports recovery. Repeat after a planned CORE reboot and driver update. This stores a fixed, harmless value with the encryption flag; it does not validate real Matter key handling or backup security. Removing/re-adding the driver may lose driver-scoped persistence.

For IPv6 UDP testing, use a computer on the same LAN with a reachable IPv6 address. Run the supplied echo script manually in PowerShell:

```powershell
.\tools\ipv6-echo.ps1 -BindAddress 'YOUR_COMPUTER_IPV6_ADDRESS'
```

Set **Probe IPv6 Address** to that address without brackets, port 55490, then run **Run IPv6 UDP Echo Probe**. Prefer a routable local IPv6 address for the first test; link-local addresses need the CORE's own interface scope, which is still unresolved. The script exits after 120 seconds and makes no firewall changes. A timeout does not establish lack of IPv6 support: check responder, address, firewall and route. A pass establishes only that one binary unicast round-trip.

## Commissioning status

No commissioning action or setup-code property is offered in this spike. There are no Matter credentials to clear. This deliberately avoids presenting unimplemented actions as functional. The intended eventual flow remains Aqara multi-admin sharing -> a new controller fabric -> descriptor discovery -> verified Signal subscription.

For a future helper, the [official CHIP guide](https://project-chip.github.io/connectedhomeip-doc/development_controllers/chip-tool/chip_tool_guide.html) explains commissioning with the fresh sharing code from the existing administrator. That is a research procedure, not a completed installation path for this driver. Never remove/reset the Aqara fabric to test multi-admin.

## Build and validate

From this folder:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

Build uses standard ZIP packaging with `driver.xml` and `driver.lua` at the root, following [Control4 packaging conventions](https://github.com/control4/drivers-driverpackager). The driver is unencrypted so its diagnostics can be inspected.

With a Lua 5.1 interpreter, run `lua tests/driver_spec.lua`. See [validation record](docs/VALIDATION.md) for actual results and pending hardware tests.

## Troubleshooting and limitations

- Missing event: confirm driver initialization and inspect Last Error; reload the driver before programming it.
- Test event works but speakers are silent: inspect the Announcement Agent configuration and the attached Composer programming.
- Physical doorbell produces nothing: expected in this spike; Matter is not implemented.
- Simulation does not ring: enable debugging, establish an inactive baseline, then activate; check debounce.
- No crypto module: record the actual Director version; local Composer version does not prove controller capability.
- Persistent canary missing: distinguish write latency, restart, update and remove/re-add tests.
- IPv6 pass does not prove mDNS, multicast, commissioning, subscription or reboot recovery.
- Existing alpha driver and live project were not changed. No SDK/helper was installed, no M100 pairing performed and no household announcement triggered by this work.
