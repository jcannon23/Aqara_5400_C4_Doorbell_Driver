$ErrorActionPreference='Stop'
$module=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'experimental/ccm.lua') -Raw
$vectors=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tests/ccm_vectors.lua') -Raw
$body=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'experimental/ccm_probe_body.lua') -Raw
$bundle="-- Generated standalone probe: paste all into Composer Lua Command.`n" +
  "do`nlocal CCM=(function()`n"+$module+"`nend)()`nlocal vectors=(function()`n"+$vectors+"`nend)()`n"+$body+"`nend`n"
[System.IO.File]::WriteAllText((Join-Path $PSScriptRoot 'tools/core-ccm-probe.lua'),$bundle,(New-Object System.Text.UTF8Encoding($false)))
