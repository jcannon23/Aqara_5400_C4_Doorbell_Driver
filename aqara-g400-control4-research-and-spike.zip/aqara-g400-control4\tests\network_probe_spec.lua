local timers,output={},{}
local old=function() end
ReceivedFromNetwork=old; OnNetworkStatusChanged=old
C4={
 UUID=function() return 'test-id' end,
 SetTimer=function(_,delay,fn) local t={delay=delay,fn=fn,Cancel=function() end}; timers[#timers+1]=t; return t end,
 CreateNetworkConnection=function() end,NetConnect=function() end,NetDisconnect=function() end,
 SendToNetwork=function(_,id,port,data) if id==6992 then ReceivedFromNetwork(id,port,data) end end,
}
local originalPrint=print
print=function(s) output[#output+1]=s end
dofile('tools/core-network-probe.lua')
table.sort(timers,function(a,b) return a.delay<b.delay end)
for _,t in ipairs(timers) do t.fn() end
print=originalPrint
assert(ReceivedFromNetwork==old and OnNetworkStatusChanged==old)
assert(AqaraNetworkProbeRunning==nil)
local text=table.concat(output,'\n')
assert(text:find('IPv4 RESULT: PASS'))
assert(text:find('IPv6 RESULT: NO ECHO'))
print('PASS: network probe comparison and callback restoration (mock C4).')
