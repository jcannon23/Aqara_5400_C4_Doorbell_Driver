local CCM = dofile('experimental/ccm.lua')
local vectors = dofile('tests/ccm_vectors.lua')
assert(type(TestAES) == 'function', 'Use the local .NET AES test runner')
local count = 0
local function check(value) assert(value); count=count+1 end
local function h(s) return (s:gsub('%x%x',function(p) return string.char(tonumber(p,16)) end)) end
local function flip(s,i) return s:sub(1,i-1)..string.char((s:byte(i)+1)%256)..s:sub(i+1) end
for _,v in ipairs(vectors) do
  local k,n,a,p,c = h(v.key),h(v.nonce),h(v.aad),h(v.plaintext),h(v.packet)
  check(CCM.encrypt(TestAES,k,n,a,p,v.tag)==c)
  check(CCM.decrypt(TestAES,k,n,a,c,v.tag)==p)
  for i=1,#c do check(CCM.decrypt(TestAES,k,n,a,flip(c,i),v.tag)==nil) end
  check(CCM.decrypt(TestAES,k,n,flip(a,1),c,v.tag)==nil)
  check(CCM.decrypt(TestAES,k,flip(n,1),a,c,v.tag)==nil)
  check(CCM.decrypt(TestAES,flip(k,1),n,a,c,v.tag)==nil)
end
local key,nonce = string.rep('\0',16),string.rep('\0',13)
for _,length in ipairs({0,1,15,16,17,1280}) do
  local p=string.rep('\255',length)
  local c=assert(CCM.encrypt(TestAES,key,nonce,'',p,16))
  check(CCM.decrypt(TestAES,key,nonce,'',c,16)==p)
end
check(CCM.encrypt(TestAES,key,nonce,'',string.rep('x',1281),16)==nil)
check(CCM.encrypt(TestAES,key,nonce,'','x',5)==nil)
check(CCM.encrypt(TestAES,key,'short','','x',16)==nil)
check(CCM.decrypt(TestAES,key,nonce,'','short',16)==nil)
check(CCM.encrypt(function() error('secret') end,key,nonce,'','x',16)==nil)
print('PASS: '..count..' CCM assertions with native .NET AES; not CORE hardware.')
