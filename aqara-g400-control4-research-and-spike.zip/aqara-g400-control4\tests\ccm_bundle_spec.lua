local output,queue={},{}
local env=setmetatable({
  print=function(s) output[#output+1]=s end,
  require=function(name)
    assert(name=='openssl')
    return {cipher={encrypt=function(alg,p,k,iv,pad)
      assert(alg=='aes-128-ecb' and iv==nil and pad==false)
      return TestAES(k,p)
    end}}
  end,
  C4={GetTickCount=function() return 0 end,
    SetTimer=function(_,delay,fn) queue[#queue+1]=fn; return {} end},
},{__index=_G})
local chunk=assert(loadfile('tools/core-ccm-probe.lua'))
setfenv(chunk,env); chunk()
local i=1
while queue[i] do queue[i](); i=i+1; assert(i<=11) end
assert(table.concat(output,'\n'):find('RESULT 10/10 passed'))
print('PASS: bundled CORE probe completes all 10 tests with .NET AES backend.')
