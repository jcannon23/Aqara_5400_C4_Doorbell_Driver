param([Parameter(Mandatory=$true)][string]$BindAddress, [int]$Port=55490, [int]$Seconds=120)
$ErrorActionPreference = 'Stop'
$ip = [System.Net.IPAddress]::Parse($BindAddress)
if ($ip.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetworkV6) { throw 'IPv6 address required' }
if ($Port -lt 1024 -or $Port -gt 65535 -or $Seconds -lt 1 -or $Seconds -gt 600) { throw 'Invalid port or duration' }
$udp = New-Object System.Net.Sockets.UdpClient([System.Net.Sockets.AddressFamily]::InterNetworkV6)
try {
  $udp.Client.Bind((New-Object System.Net.IPEndPoint($ip,$Port)))
  $udp.Client.ReceiveTimeout = 1000
  $deadline = [DateTime]::UtcNow.AddSeconds($Seconds)
  Write-Output "Echo responder active on [$BindAddress]:$Port for $Seconds seconds."
  while ([DateTime]::UtcNow -lt $deadline) {
    $peer = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::IPv6Any,0)
    try { $bytes = $udp.Receive([ref]$peer) }
    catch [System.Net.Sockets.SocketException] {
      if ($_.Exception.SocketErrorCode -eq [System.Net.Sockets.SocketError]::TimedOut) { continue }
      throw
    }
    # Only echo this spike's small diagnostic messages, never arbitrary traffic.
    if ($bytes.Length -le 128 -and [System.Text.Encoding]::ASCII.GetString($bytes).StartsWith('AQARA-SPIKE:')) {
      [void]$udp.Send($bytes,$bytes.Length,$peer)
      Write-Output 'Echoed diagnostic packet.'
    }
  }
} finally { $udp.Dispose() }
