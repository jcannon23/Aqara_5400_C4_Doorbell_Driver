# Codex Handoff Spec: Aqara G400 Matter Signal Receiver for Control4 CORE 1

## Objective

Build a single-purpose Control4 `.c4z` DriverWorks driver whose only job is to receive the Aqara G400 doorbell press signal exposed through an Aqara M100 Matter bridge and convert it into a native Control4 programming event.

Target flow:

`Aqara G400 → Aqara M100 Matter signal → Control4 CORE 1 custom driver → Doorbell Pressed event → Control4 Announcement Agent`

This is intentionally **not** a general-purpose Matter controller.

## Existing Environment

- Control4 controller: CORE 1
- Composer Pro access is available
- Aqara G400 doorbell is installed and operational
- Aqara Hub M100 is installed and operational
- Aqara Home contains a Signal configured as:
  - IF: `G400 → Doorbell Press Detected`
  - Execution device: `M100`
  - `Add to Matter`: enabled
- Existing Control4 audio zones and Announcement Agent are available
- Desired output is a Control4 event that can be programmed to play the home's doorbell chime
- Avoid Home Assistant, Node-RED, MQTT, cloud middleware, Raspberry Pi, or commercial Control4 Matter drivers unless a pure CORE 1 implementation proves technically infeasible

## Architectural Principle

Do not recreate a full Matter controller.

Implement the narrowest possible Matter feature set required to:

1. Commission the M100 using Matter multi-admin
2. Persist credentials
3. Reconnect after restart
4. Discover endpoints
5. Identify the Aqara virtual Signal endpoint
6. Subscribe to the signal state
7. Fire a Control4 `Doorbell Pressed` event on activation

Everything unrelated to that flow is out of scope.

## Expected Matter Representation

Aqara Advanced Matter Bridging exposes Conditions as Signals. The G400 doorbell press Signal is expected to appear as a Matter sensor endpoint, likely as an Occupancy Sensor.

Expected objects to investigate:

- Matter Occupancy Sensor device type
- Occupancy Sensing cluster
- Occupancy attribute
- Runtime-discovered endpoint ID

Do **not** hard-code endpoint IDs.

Do **not** assume the precise Matter cluster/device representation without validating it against the M100 during discovery.

If Aqara exposes the Signal differently, adapt the driver to the actual endpoint and cluster returned by the device.

# Non-Negotiable Phase 0: Feasibility Spike

Before implementing Matter itself, determine whether a self-contained `.c4z` can realistically perform the required Matter functions on a CORE 1.

Do not spend substantial time implementing Matter until this is answered.

## Investigate Control4 / DriverWorks Runtime Capabilities

Determine whether the runtime supports, directly or through practical pure-Lua implementations:

- IPv6 sockets
- UDP over IPv6
- IPv6 multicast
- mDNS / DNS-SD discovery
- TCP over IPv6
- secure random generation
- SHA-256
- HMAC-SHA256
- HKDF-SHA256
- AES-CCM
- elliptic-curve cryptography required by Matter
- certificate parsing
- operational certificate handling
- persistent binary storage
- timers
- asynchronous network callbacks
- unsolicited inbound traffic
- reconnect and resubscribe logic
- binary packet handling
- adequate performance without blocking Director

Search and inspect:

- Control4 DriverWorks documentation
- installed SDK/reference material
- existing Control4 network driver examples
- public Control4 API documentation
- existing `.c4z` drivers that use IPv6, TLS, crypto, or multicast
- runtime introspection where useful

## Required Deliverable

Create `FEASIBILITY.md` with a table like:

| Requirement | Available | API / implementation | Risk |
|---|---|---|---|
| IPv6 UDP | Yes/No | ... | Low/Med/High |
| AES-CCM | Yes/No | ... | ... |

Conclude with one of:

### GO
A self-contained `.c4z` is viable.

### CONDITIONAL GO
A self-contained `.c4z` is viable, but one or more primitives must be implemented in Lua.

### NO-GO
Critical Matter functionality cannot reasonably be implemented within DriverWorks.

If NO-GO:

- stop before building a fake or unreliable Matter stack
- document the exact blockers
- identify the smallest possible external helper
- define the local interface between that helper and Control4
- keep the Control4-facing driver design intact

# Phase 1: Driver Skeleton

Build a minimal Control4 driver before Matter support.

## Driver Identity

Suggested name: `Aqara G400 Matter Doorbell`

Suggested filename: `aqara_g400_matter_doorbell.c4z`

## Composer Properties

Expose:

- `Status`
- `Matter Node ID`
- `Matter Fabric ID`
- `M100 Address`
- `Doorbell Endpoint`
- `Signal Device Type`
- `Signal Cluster`
- `Last Doorbell Press`
- `Last Matter Message`
- `Last Error`
- `Debounce Seconds`
- `Debug Logging`

Recommended defaults:

- Debounce Seconds: `3`
- Debug Logging: `Off`

## Composer Actions

Add:

- `Commission M100`
- `Discover Matter Endpoints`
- `Reconnect Matter Session`
- `Test Doorbell Event`
- `Dump Matter Endpoints`
- `Clear Matter Credentials`

`Clear Matter Credentials` must not happen accidentally. Require either a confirmation property/state or clearly separated action logic.

## Composer Event

Expose exactly one primary programming event:

`Doorbell Pressed`

Optional later events:

- `Matter Connected`
- `Matter Disconnected`

Do not add unnecessary events in v1.

# Phase 2: Matter Commissioning

The M100 is already part of another Matter fabric.

Implement secondary-controller commissioning through Matter multi-admin.

## Desired User Flow

1. User puts the M100 into Matter multi-admin sharing mode using Aqara Home
2. Aqara provides a Matter setup code
3. User enters the setup code into the Control4 driver
4. Driver commissions the M100
5. Driver stores:
   - fabric information
   - node ID
   - operational credentials
   - certificates
   - any other required session material
6. Driver reconnects later without recommissioning

## Requirements

- Never log setup codes in normal logs
- Never expose private keys in Composer properties
- Never expose operational credentials in debug output
- Persist credentials across Director restart
- Survive CORE 1 reboot
- Detect stale or invalid credentials
- Provide a clear error if the M100 must be recommissioned

# Phase 3: Matter Discovery

After commissioning:

1. Establish an operational session
2. Query the M100 endpoint descriptor information
3. Enumerate endpoints
4. Enumerate device types
5. Enumerate clusters
6. Find candidate virtual signal endpoints
7. Identify the Signal representing the G400 press

## Discovery Strategy

Do not assume endpoint number.

Prefer matching based on:

1. Matter device type
2. supported cluster(s)
3. semantic/label metadata if exposed
4. endpoint behavior
5. user selection if multiple candidates remain

If multiple occupancy/sensor endpoints are discovered, expose a Composer property allowing the user to select the target endpoint.

The `Dump Matter Endpoints` action should output a concise diagnostic list showing:

- endpoint ID
- device type
- clusters
- labels/names if available

Do not dump secrets.

# Phase 4: Doorbell Event Subscription

Subscribe to the relevant Matter attribute/event rather than polling if possible.

Expected behavior:

- signal inactive → no event
- signal becomes active → fire `Doorbell Pressed`
- signal remains active → do not repeatedly fire
- signal returns inactive → re-arm
- subsequent activation → fire again

Also apply configurable debounce.

## Debounce Logic

Default: 3 seconds

Rules:

- Ignore duplicate activation reports inside the debounce window
- Do not block the Lua thread
- Use timers/state instead of sleep
- Track last accepted press timestamp
- Allow repeated legitimate presses after debounce expiration

# Phase 5: Control4 Integration

The driver must expose a clean event that Composer can use directly.

Desired programming:

`WHEN Aqara G400 Matter Doorbell → Doorbell Pressed`

then:

`EXECUTE Front Doorbell Announcement`

No polling logic should be required in Composer.

The driver should behave as a native event source.

# Phase 6: Reliability

The driver must recover from normal failures without manual intervention.

Handle:

- M100 reboot
- CORE 1 reboot
- network outage
- DHCP address change
- Matter session timeout
- subscription expiration
- Matter bridge restart
- IPv6 address changes
- transient packet loss

Expected recovery:

1. detect loss of session
2. retry with backoff
3. rediscover the M100 if necessary
4. re-establish operational session
5. re-subscribe to the doorbell Signal
6. update `Status`

Suggested states:

- `Not Commissioned`
- `Commissioning`
- `Connected`
- `Discovering`
- `Subscribed`
- `Disconnected`
- `Retrying`
- `Error`

# Phase 7: Logging

Implement structured debug logging.

Prefix all messages with:

`[Aqara G400 Matter]`

Debug levels:

- Error
- Info
- Debug
- Trace

Normal user mode should not flood Director logs.

Useful log examples:

- commissioned M100
- operational session established
- endpoints discovered
- selected Signal endpoint
- subscription established
- doorbell activation received
- duplicate activation ignored
- reconnect scheduled
- session restored

Never log:

- private keys
- full certificates unless explicitly redacted
- setup passcodes
- session secrets

# Phase 8: Test Harness

Include a `Test Doorbell Event` action.

It should fire the exact same Control4 `Doorbell Pressed` event used by the real Matter signal.

This allows independent validation of:

`Control4 driver → Composer event → Announcement Agent → speakers`

before Matter is working.

Also add an optional debug action:

`Simulate Signal Active`

This should pass through the same debounce/event logic as a real Matter update.

# Phase 9: Validation Plan

## Functional

- Press G400 once → one Control4 event
- Press twice slowly → two events
- Press repeatedly rapidly → debounce behaves correctly
- Motion without pressing doorbell → no event
- Person detection without press → no event

## Restart

- restart Director
- reboot CORE 1
- reboot M100
- reboot G400

After each restart, the driver should reconnect without recommissioning.

## Network

- unplug M100 network/power temporarily
- restore it
- confirm automatic reconnect
- change M100 DHCP lease/IP
- confirm rediscovery

## Matter

- invalid setup code
- expired setup code
- subscription loss
- endpoint unavailable
- Signal endpoint removed/recreated

## Control4

- Test Doorbell Event triggers Announcement
- real G400 press triggers same Announcement
- driver reinstall behavior documented
- credentials survive driver update if Control4 permits

# Definition of Done

The driver is complete when:

1. M100 can be commissioned through multi-admin
2. commissioning persists across CORE 1 restart
3. the M100 can be rediscovered automatically
4. the G400 virtual Matter Signal can be identified
5. driver subscribes to the Signal
6. physical G400 press produces exactly one `Doorbell Pressed` event
7. motion/person detection does not trigger the event
8. reconnect works after M100 reboot
9. reconnect works after CORE 1 reboot
10. Composer can trigger the existing Control4 Announcement Agent from the event
11. no Home Assistant or cloud middleware is required
12. no Matter credentials or private keys appear in logs

# Out of Scope for v1

Do not implement:

- G400 RTSP video
- ONVIF
- two-way audio
- snapshots
- package detection
- motion events
- person detection
- Aqara cloud API
- HomeKit
- generic Matter device support
- Thread devices
- Matter lighting
- Matter thermostats
- Matter locks
- Matter scene control
- general Matter UI
- multiple Matter bridges unless needed for testing

Keep v1 narrowly focused on the G400 doorbell press.

# Suggested Project Structure

```text
aqara-g400-control4/
├── README.md
├── FEASIBILITY.md
├── docs/
│   ├── architecture.md
│   ├── commissioning.md
│   ├── testing.md
│   └── troubleshooting.md
├── driver/
│   ├── driver.xml
│   ├── driver.lua
│   ├── matter/
│   │   ├── codec.lua
│   │   ├── crypto.lua
│   │   ├── discovery.lua
│   │   ├── commissioning.lua
│   │   ├── session.lua
│   │   ├── interaction_model.lua
│   │   └── subscription.lua
│   └── util/
│       ├── logging.lua
│       ├── persistence.lua
│       └── timers.lua
├── tests/
│   ├── unit/
│   └── fixtures/
└── build/
```

Adapt to actual Control4 driver packaging conventions as necessary.

# Development Rules

1. Do not fabricate Control4 APIs.
2. Verify every DriverWorks API against documentation or an existing working sample.
3. Do not assume a cryptographic primitive exists until confirmed.
4. Do not block Director with long-running synchronous work.
5. Keep Matter parsing binary-safe.
6. Keep protocol state machines explicit.
7. Keep persistent credential format versioned.
8. Comment Matter constants with their specification references.
9. Keep Aqara-specific assumptions isolated from generic Matter transport code.
10. Fail clearly instead of silently.

# Research Priorities

Codex should answer these first:

1. Can CORE 1 DriverWorks open IPv6 UDP/TCP sockets?
2. Can a `.c4z` perform mDNS/DNS-SD discovery?
3. What cryptography is exposed by the Control4 runtime?
4. Is AES-CCM available?
5. Is P-256/ECDH/ECDSA available?
6. Can required Matter credentials be stored securely/persistently?
7. Can DriverWorks reliably maintain Matter subscriptions?
8. Does the M100 virtual Signal appear as an Occupancy Sensor in practice?
9. What endpoint/cluster/attribute changes when the G400 button is pressed?
10. Can the M100 be commissioned as a secondary Matter fabric directly from a custom controller?

# Important Engineering Decision

If Phase 0 shows that implementing Matter security/session handling inside Control4 is impractical, stop.

Do not sink time into a fragile pure-Lua Matter stack merely to preserve a single-file architecture.

In that case, create a minimal companion architecture:

`M100 → tiny local Matter helper → authenticated LAN event → Control4 .c4z`

The helper should only handle Matter and emit a tiny local event. The Control4 driver should remain the owner of:

- doorbell semantics
- debounce
- status
- Composer event
- Control4 Announcement integration

Only take this fallback if the pure CORE 1 implementation fails the feasibility gate.

# Final Deliverables

Codex should produce:

1. `FEASIBILITY.md`
2. source files
3. built `.c4z`
4. installation instructions
5. commissioning instructions
6. Composer programming instructions
7. troubleshooting guide
8. test checklist
9. list of known limitations
10. short technical summary explaining whether Matter runs entirely on CORE 1 or requires a helper

# Success Experience

The final user experience should be:

1. Add driver to Control4
2. Put M100 into Matter multi-admin pairing mode
3. Enter Matter code in driver
4. Driver discovers `Front Doorbell Press`
5. Press G400
6. Composer receives `Doorbell Pressed`
7. Whole-home Control4 chime plays

After initial setup, the system should operate locally and automatically without Aqara cloud automation, Home Assistant, or manual intervention.
