-- Public RFC 3610 #1 and CAVP CCM-VTT128 Count 60 test data.
return {
  {name='RFC3610 packet 1', tag=8,
    key='c0c1c2c3c4c5c6c7c8c9cacbcccdcecf', nonce='00000003020100a0a1a2a3a4a5',
    aad='0001020304050607', plaintext='08090a0b0c0d0e0f101112131415161718191a1b1c1d1e',
    packet='588c979a61c663d2f066d0c2c0f989806d5f6b61dac38417e8d12cfdf926e0'},
  {name='CAVP VTT128 count 60, 13-byte nonce / 16-byte tag', tag=16,
    key='4189351b5caea375a0299e81c621bf43', nonce='48c0906930561e0ab0ef4cd972',
    aad='40a27c1d1e23ea3dbe8056b2774861a4a201cce49f19997d19206d8c8a343951',
    plaintext='4535d12b4377928a7c0a61c9f825a48671ea05910748c8ef',
    packet='26c56961c035a7e452cce61bc6ee220d77b3f94d18fd10b6d80e8bf80f4a46cab06d4313f0db9be9'}
}
