-- Generated standalone probe: paste all into Composer Lua Command.
do
local CCM=(function()
-- Experimental bounded AES-CCM composition, RFC 3610 sections 2.2-2.5.
-- Caller supplies native AES-128 block encryption; no AES implementation here.
-- Not wired to the driver. Nonce uniqueness/replay protection belong to sessions.
local CCM = {}
local LIMIT = 1280
local function xorByte(a, b)
  local out, bit = 0, 1
  for _ = 1, 8 do
    out = out + ((a % 2 + b % 2) % 2) * bit
    a = math.floor(a / 2); b = math.floor(b / 2); bit = bit * 2
  end
  return out
end
local function xor(a, b)
  local out = {}
  for i = 1, #a do out[i] = string.char(xorByte(a:byte(i), b:byte(i))) end
  return table.concat(out)
end
local function be(n, width)
  local out = {}
  for i = width, 1, -1 do out[i] = string.char(n % 256); n = math.floor(n / 256) end
  return table.concat(out)
end
local function pad(data) return data .. string.rep('\0', (16 - #data % 16) % 16) end
local function valid(key, nonce, aad, data, tagLength)
  return type(key) == 'string' and #key == 16 and type(nonce) == 'string' and
    #nonce >= 7 and #nonce <= 13 and type(aad) == 'string' and #aad <= LIMIT and
    type(data) == 'string' and #data <= LIMIT and type(tagLength) == 'number' and
    tagLength >= 4 and tagLength <= 16 and tagLength % 2 == 0
end
local function cipher(aes, key)
  return function(block)
    local result = aes(key, block)
    if type(result) ~= 'string' or #result ~= 16 then error('AES block failure') end
    return result
  end
end
local function mac(enc, nonce, aad, plaintext, tagLength)
  local width = 15 - #nonce
  local flags = (#aad > 0 and 64 or 0) + (tagLength - 2) * 4 + width - 1
  local state = enc(string.char(flags) .. nonce .. be(#plaintext, width))
  local function feed(data)
    data = pad(data)
    for i = 1, #data, 16 do state = enc(xor(state, data:sub(i, i+15))) end
  end
  -- Bounded AAD uses the RFC's two-byte length form (< 65280).
  if #aad > 0 then feed(be(#aad, 2) .. aad) end
  feed(plaintext)
  return state:sub(1, tagLength)
end
local function stream(enc, nonce, data)
  local width, out = 15 - #nonce, {}
  local prefix = string.char(width - 1) .. nonce
  for i = 1, #data, 16 do
    out[#out+1] = xor(data:sub(i,i+15), enc(prefix .. be((i-1)/16+1, width)))
  end
  return table.concat(out), enc(prefix .. be(0, width))
end
function CCM.encrypt(aes, key, nonce, aad, plaintext, tagLength)
  if type(aes) ~= 'function' or not valid(key,nonce,aad,plaintext,tagLength) then return nil, 'invalid input' end
  local ok, output = pcall(function()
    local enc = cipher(aes,key)
    local ciphertext, mask = stream(enc,nonce,plaintext)
    return ciphertext .. xor(mac(enc,nonce,aad,plaintext,tagLength), mask)
  end)
  if not ok then return nil, 'crypto failure' end
  return output
end
function CCM.decrypt(aes, key, nonce, aad, packet, tagLength)
  if type(packet) ~= 'string' or type(tagLength) ~= 'number' or tagLength % 2 ~= 0 or
      tagLength < 4 or tagLength > 16 or #packet < tagLength or #packet > LIMIT + tagLength then
    return nil, 'invalid input'
  end
  local ciphertext = packet:sub(1, #packet-tagLength)
  if type(aes) ~= 'function' or not valid(key,nonce,aad,ciphertext,tagLength) then return nil, 'invalid input' end
  local ok, plaintext = pcall(function()
    local enc = cipher(aes,key)
    local candidate, mask = stream(enc,nonce,ciphertext)
    local expected = xor(mac(enc,nonce,aad,candidate,tagLength), mask)
    local supplied = packet:sub(#packet-tagLength+1)
    -- Compare all bytes; no early-exit comparison. Lua execution is not claimed constant-time.
    local diff = 0
    for i = 1, tagLength do diff = diff + xorByte(expected:byte(i), supplied:byte(i)) end
    if diff ~= 0 then return nil end
    return candidate -- Never return unauthenticated plaintext.
  end)
  if not ok then return nil, 'crypto failure' end
  if plaintext == nil then return nil, 'authentication failed' end
  return plaintext
end
return CCM

end)()
local vectors=(function()
-- Public RFC 3610 #1 and CAVP CCM-VTT128 Count 60 test data.
return {
  {name='RFC3610 packet 1', tag=8,
    key='c0c1c2c3c4c5c6c7c8c9cacbcccdcecf', nonce='00000003020100a0a1a2a3a4a5',
    aad='0001020304050607', plaintext='08090a0b0c0d0e0f101112131415161718191a1b1c1d1e',
    packet='588c979a61c663d2f066d0c2c0f989806d5f6b61dac38417e8d12cfdf926e0'},
  {name='CAVP VTT128 count 60, 13-byte nonce / 16-byte tag', tag=16,
    key='4189351b5caea375a0299e81c621bf43', nonce='48c0906930561e0ab0ef4cd972',
    aad='40a27c1d1e23ea3dbe8056b2774861a4a201cce49f19997d19206d8c8a343951',
    plaintext='4535d12b4377928a7c0a61c9f825a48671ea05910748c8ef',
    packet='26c56961c035a7e452cce61bc6ee220d77b3f94d18fd10b6d80e8bf80f4a46cab06d4313f0db9be9'}
}

end)()
-- Appended to the bundled CCM module and public vectors by build-ccm-probe.ps1.
local prefix = '[Aqara CCM Probe v3] '
local function say(message) print(prefix .. message) end
local function h(s) return (s:gsub('%x%x',function(p) return string.char(tonumber(p,16)) end)) end
local function flip(s,i) return s:sub(1,i-1)..string.char((s:byte(i)+1)%256)..s:sub(i+1) end
say('BEGIN - experimental adapter, not a Matter session')
local ok,ssl=pcall(require,'openssl')
if not ok or type(ssl)~='table' then say('OpenSSL unavailable'); say('END'); return end
local function aes(key,block) return ssl.cipher.encrypt('aes-128-ecb',block,key,nil,false) end
local queue={}
for _,vector in ipairs(vectors) do
  local v=vector
  local k,n,a,p,c=h(v.key),h(v.nonce),h(v.aad),h(v.plaintext),h(v.packet)
  local function add(name,fn) queue[#queue+1]={v.name..' / '..name,fn} end
  add('known-answer encryption',function() return CCM.encrypt(aes,k,n,a,p,v.tag)==c end)
  add('known-answer decryption',function() return CCM.decrypt(aes,k,n,a,c,v.tag)==p end)
  add('reject altered tag',function()
    local value,err=CCM.decrypt(aes,k,n,a,flip(c,#c),v.tag)
    return value==nil and err=='authentication failed'
  end)
  add('reject altered ciphertext',function()
    local value,err=CCM.decrypt(aes,k,n,a,flip(c,1),v.tag)
    return value==nil and err=='authentication failed'
  end)
  add('reject altered AAD',function()
    local value,err=CCM.decrypt(aes,k,n,flip(a,1),c,v.tag)
    return value==nil and err=='authentication failed'
  end)
end
local index,passed=0,0
local function tick()
  local success,value=pcall(function() return C4:GetTickCount() end)
  return success and type(value)=='number' and value or nil
end
local function step()
  index=index+1
  local item=queue[index]
  if not item then
    say('RESULT '..passed..'/'..#queue..' passed')
    say('SPAKE2+, IPv6, persistence and commissioning remain unvalidated')
    say('END'); return
  end
  local start=tick()
  local ran,result=pcall(item[2])
  local finish=tick()
  local success=ran and result==true
  if success then passed=passed+1 end
  local elapsed=start and finish and finish>=start and ('; elapsed_ms='..(finish-start)) or ''
  say(item[1]..': '..(success and 'PASS' or 'FAIL / API ERROR')..elapsed)
  local scheduled,timer=pcall(function() return C4:SetTimer(100,step) end)
  if not scheduled or not timer then say('STOP: timer unavailable'); say('END') end
end
step()

end
