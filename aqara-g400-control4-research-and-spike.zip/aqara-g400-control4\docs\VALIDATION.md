# Validation record

2026-09-26: **23 behavioral assertions passed** using the installed Windows Lua 5.1 DLL and mocked C4 APIs. This was not the CORE 1 runtime.

Build completed. The XML parses, the `.c4z` has exactly the two expected root entries, and both packaged files match source. The echo responder passes PowerShell syntax validation; its live networking has not been exercised.

Step 2: the standalone native crypto probe passes **8 control-flow assertions** covering missing modules, per-test API errors, timer progression, completion, timer failure and suppression of raw error contents. These tests do not validate crypto. CORE 1 OS 4.0.0 is user-confirmed; operational probe results remain pending.

Covered: initialization lifecycle, event ID, disabled simulations, initial active baseline, rising edges, held-active suppression after timer expiry, re-arming, rapid presses, no delayed replay, manual test bypass, mocked persistence reload, binary echo acceptance, unrelated-packet rejection, timeout cleanup, timer cancellation, no network-triggered rings, IPv4 rejection, absent capability handling, zero debounce and destroyed-driver behavior.

Runtime crypto probe includes SHA-256 `abc` and the first HMAC-SHA256 case from [RFC 4231](https://www.rfc-editor.org/rfc/rfc4231.html). Those probes have not run against actual C4 crypto APIs.

## Required hardware acceptance checks — all pending

- [ ] Import `.c4z` in Composer; verify one primary event and working action dispatch.
- [ ] Test Doorbell Event -> Composer -> Announcement Agent -> intended speakers.
- [ ] Record CORE 1 OS version and native capability probe results.
- [ ] Verify real encrypted persistence across Director restart, CORE reboot and driver update.
- [ ] IPv6 UDP echo, link-local scope, multicast and DNS-SD discovery.
- [ ] AES-CCM vectors/tag rejection, P-256, SPAKE2+ and Director latency.
- [ ] M100 secondary-fabric commissioning and credential recovery.
- [ ] Dynamic endpoint/cluster discovery, actual Signal identification and re-creation handling.
- [ ] Physical press once/twice/rapidly; characterize Signal reset duration.
- [ ] Motion/person detection never triggers press event.
- [ ] M100/G400/CORE restart recovery; network and IPv6/DHCP changes.
- [ ] Invalid/expired setup code, lost subscription and unavailable endpoint handling.
- [ ] Inspect normal/debug logs and backups for credential exposure.

The handoff's definition of done is not met. Full Matter implementation has not begun. Native feasibility has been reopened following the commercial-driver evidence; the diagnostic build and its test results are unchanged.
