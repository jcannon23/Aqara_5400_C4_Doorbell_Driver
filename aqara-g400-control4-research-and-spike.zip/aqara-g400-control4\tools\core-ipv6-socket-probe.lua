-- Diagnostic only: documented LuaSocket APIs, nonblocking reads, 5s lifetime.
do
  local function say(s) print('[Aqara IPv6 Probe v5] '..s) end
  say('BEGIN')
  local ok,socket=pcall(require,'socket')
  if not ok then ok,socket=pcall(require,'socket.core') end
  if not ok or type(socket)~='table' then say('LuaSocket unavailable'); say('END'); return end
  say('LuaSocket version: '..tostring(socket._VERSION))
  say('udp6 constructor: '..type(socket.udp6))
  if type(socket.udp6)~='function' then say('END - explicit IPv6 constructor unavailable'); return end
  local sockets,timers={},{}
  local done=false
  local function cleanup()
    if done then return end
    done=true
    for _,t in ipairs(timers) do pcall(function() t:Cancel() end) end
    for _,s in ipairs(sockets) do pcall(function() s:close() end) end
  end
  local function make()
    local s,err=socket.udp6()
    if not s then say('udp6 creation error: '..tostring(err)); return end
    sockets[#sockets+1]=s
    local nonblocking,timeoutError=s:settimeout(0)
    if not nonblocking then say('Nonblocking setup failed: '..tostring(timeoutError)); return end
    return s
  end
  local ran=pcall(function()
    local nonce=assert(C4:UUID('RANDOM'))
    local payload='AQARA-NET4:IPv6-direct:'..nonce..'\0\255'
    local loop,lan=make(),make()
    local loopReady,lanReady,loopPass,lanPass=false,false,false,false
    -- Schedule cleanup before any send/receive operation.
    timers[#timers+1]=assert(C4:SetTimer(5000,function()
      say('IPv6 loopback RESULT: '..(loopPass and 'PASS' or 'NOT VERIFIED'))
      say('IPv6 LAN RESULT: '..(lanPass and 'PASS' or 'NOT VERIFIED'))
      cleanup(); say('END - sockets closed')
    end))
    if loop then
      local bound,err=loop:setsockname('::1',0)
      say('Loopback bind: '..tostring(bound)..' '..tostring(err or ''))
      if bound then
        local address,port=loop:getsockname()
        local sent,sendError=loop:sendto(payload,address,port)
        loopReady=sent~=nil
        say('Loopback send: '..tostring(sent)..' '..tostring(sendError or ''))
      end
    end
    if lan then
      local connected,err=lan:setpeername('fdb2:736a:697e:40e7:3a7a:74c8:d9a9:c2a1',55491)
      say('LAN setpeername: '..tostring(connected)..' '..tostring(err or ''))
      if connected then
        local address,port,family=lan:getsockname()
        say('CORE source: '..tostring(address)..':'..tostring(port)..' '..tostring(family))
        local sent,sendError=lan:send(payload)
        lanReady=sent~=nil
        say('LAN send: '..tostring(sent)..' '..tostring(sendError or ''))
      end
    end
    timers[#timers+1]=assert(C4:SetTimer(100,function()
      if done then return end
      local safe=pcall(function()
        if loopReady and not loopPass then loopPass=loop:receive()==payload end
        if lanReady and not lanPass then lanPass=lan:receive()==payload end
      end)
      if not safe then cleanup(); say('Read API error; sockets closed'); say('END') end
    end,true))
  end)
  if not ran then cleanup(); say('API error; sockets closed'); say('END') end
end
