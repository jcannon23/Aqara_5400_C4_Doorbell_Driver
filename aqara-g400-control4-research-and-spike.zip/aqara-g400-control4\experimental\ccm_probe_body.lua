-- Appended to the bundled CCM module and public vectors by build-ccm-probe.ps1.
local prefix = '[Aqara CCM Probe v3] '
local function say(message) print(prefix .. message) end
local function h(s) return (s:gsub('%x%x',function(p) return string.char(tonumber(p,16)) end)) end
local function flip(s,i) return s:sub(1,i-1)..string.char((s:byte(i)+1)%256)..s:sub(i+1) end
say('BEGIN - experimental adapter, not a Matter session')
local ok,ssl=pcall(require,'openssl')
if not ok or type(ssl)~='table' then say('OpenSSL unavailable'); say('END'); return end
local function aes(key,block) return ssl.cipher.encrypt('aes-128-ecb',block,key,nil,false) end
local queue={}
for _,vector in ipairs(vectors) do
  local v=vector
  local k,n,a,p,c=h(v.key),h(v.nonce),h(v.aad),h(v.plaintext),h(v.packet)
  local function add(name,fn) queue[#queue+1]={v.name..' / '..name,fn} end
  add('known-answer encryption',function() return CCM.encrypt(aes,k,n,a,p,v.tag)==c end)
  add('known-answer decryption',function() return CCM.decrypt(aes,k,n,a,c,v.tag)==p end)
  add('reject altered tag',function()
    local value,err=CCM.decrypt(aes,k,n,a,flip(c,#c),v.tag)
    return value==nil and err=='authentication failed'
  end)
  add('reject altered ciphertext',function()
    local value,err=CCM.decrypt(aes,k,n,a,flip(c,1),v.tag)
    return value==nil and err=='authentication failed'
  end)
  add('reject altered AAD',function()
    local value,err=CCM.decrypt(aes,k,n,flip(a,1),c,v.tag)
    return value==nil and err=='authentication failed'
  end)
end
local index,passed=0,0
local function tick()
  local success,value=pcall(function() return C4:GetTickCount() end)
  return success and type(value)=='number' and value or nil
end
local function step()
  index=index+1
  local item=queue[index]
  if not item then
    say('RESULT '..passed..'/'..#queue..' passed')
    say('SPAKE2+, IPv6, persistence and commissioning remain unvalidated')
    say('END'); return
  end
  local start=tick()
  local ran,result=pcall(item[2])
  local finish=tick()
  local success=ran and result==true
  if success then passed=passed+1 end
  local elapsed=start and finish and finish>=start and ('; elapsed_ms='..(finish-start)) or ''
  say(item[1]..': '..(success and 'PASS' or 'FAIL / API ERROR')..elapsed)
  local scheduled,timer=pcall(function() return C4:SetTimer(100,step) end)
  if not scheduled or not timer then say('STOP: timer unavailable'); say('END') end
end
step()
