# Aqara G400 / M100 / Control4 feasibility

Research date: 2026-09-26. Target: a supported, self-contained DriverWorks `.c4z` on CORE 1.

User subsequently confirmed target CORE 1 OS **4.0.0**. See [step 2](docs/NATIVE_NEXT_STEP.md) for the operational crypto probe and remaining runtime evidence.

**Hardware evidence update:** user-supplied v2 output confirms native AES block encryption, P-256 ECDH/ECDSA and BN arithmetic on Director 4.0.0.734549-res. See [CORE results and next probe](docs/CORE_RESULTS.md). Earlier capability rows describe the research baseline; these measured results supersede the candidate status for those exact primitives.

## Revised decision: native feasibility reopened; custom implementation unverified

The initial NO-GO was premature. Missing public API documentation and an unavailable low-level EC module do not establish that a supported native implementation is impractical. The user's commercial-driver reference provides substantial contrary evidence. No CORE 1 or M100 was accessed or commissioned during this work.

### Commercial precedent supplied by the user

[Solidified Systems Matter driver](https://drivercentral.io/platforms/control4-drivers/matter) describes native local commissioning/control without a third-party hub, multi-admin and sensor support. Requirements include OS 4.0+ and LAN IPv6; Wi-Fi/Ethernet devices are supported, BLE commissioning and Thread are not. Inspected version: 20260902.

This supports pursuing native Control4 Matter. The listing does not disclose its implementation, establish source availability, or explicitly confirm M100 bridged virtual Signals. We have not tested the product. It is therefore evidence of platform feasibility, not validation of our own Lua implementation or this exact doorbell flow. OS 4.0+ becomes the relevant initial target for investigating this precedent; the diagnostic spike's older minimum is only its own API floor.

Next investigation: obtain publicly available installation/runtime documentation, identify the supported networking and crypto mechanisms, and run the CORE 1 probes. Keep an external helper as a fallback, not a requirement. A final GO/CONDITIONAL GO for our implementation awaits those findings; the previous NO-GO is withdrawn.

The public Control4 documentation at the old `control4.github.io` address is incomplete for this assessment. The current [Snap One reference](https://snap-one.github.io/docs-driverworks-api/#lua-openssl-interface) documents Lua OpenSSL from OS 3.4.1, but removes the `ec` module, OpenSSL socket operations and native engine loading. `pkey` remains. Thus, claiming that DriverWorks has no modern cryptography would be incorrect.

## Capability assessment

“Unverified” does not mean unavailable. “Yes” below means a documented building block, not successful target-hardware testing.

| Requirement | Available | API / implementation | Risk |
|---|---|---|---|
| IPv6 sockets / UDP | CORE loopback and LAN pass | LuaSocket 3.0.0 udp6; C4 binding path failed as tested | Medium |
| IPv6 multicast | Unverified | MULTICAST exists; scope/interface behavior unresolved | High |
| IPv6 TCP | Unverified | TCP APIs exist; address-family behavior unresolved | Medium |
| mDNS / DNS-SD | Custom work | No dedicated API identified | High |
| Secure random | Candidate | Lua OpenSSL; runtime test required | Medium |
| SHA-256 | Yes | C4:Hash | Low |
| HMAC-SHA256 | Yes | C4:HMAC | Low |
| HKDF-SHA256 | Implementable | HMAC construction | Medium |
| AES-CCM | CORE vector tests pass | Bounded Lua composition over native AES; v3 10/10 passed | Medium |
| P-256 ECDH/ECDSA | CORE operation tests pass | OpenSSL pkey | Low |
| SPAKE2+ point arithmetic | Gap | Removed ec interface; custom alternative required | High |
| Certificate parsing | Candidate | OpenSSL x509 | Medium |
| Matter operational certificates | Custom work | Issuance, validation, TLV conversion | High |
| Persistent binary credentials | Yes, encoded | PersistSetValue/GetValue, encryption flag | Medium |
| Timers | Yes | SetTimer | Low |
| Async callbacks / unsolicited traffic | Yes | Network callbacks | Low |
| Binary packets | Yes | Lua strings | Low |
| Reconnect / subscription renewal | Custom work | State machines and timers | High |
| Nonblocking performance | Unverified | Target profiling required | High |

API evidence: [current reference](https://snap-one.github.io/docs-driverworks-api/), [legacy reference](https://control4.github.io/docs-driverworks-api/). Matter-specific work estimates and risk ratings are engineering judgments.

## Why a narrow signal receiver still needs substantial Matter

Receiving only one attribute does not remove commissioning, authentication, encryption, reliable messaging, certificate handling, replay protection, or subscription maintenance. Multi-admin creates another fabric; it does not hand the new controller an existing authenticated session.

The [official CHIP OpenSSL implementation](https://github.com/project-chip/connectedhomeip/blob/master/src/crypto/CHIPCryptoPALOpenSSL.cpp) implements SPAKE2+ with point multiplication, addition, inversion and validation. Its AES-CCM path handles additional authenticated data and authentication tags. Generic ECDH/signing and a cipher name in a list are insufficient evidence for those requirements.

A pure-Lua point implementation might be possible. It would need vetted arithmetic, test vectors, side-channel consideration and a cooperative execution strategy. No reusable open-source DriverWorks Matter implementation was identified. The commercial precedent means we should investigate how the supported runtime can meet these needs before deciding a custom stack requires a helper.

## Aqara representation

[Aqara documents Conditions as Signals as virtual occupancy sensors](https://www.aqara.com/en/explore/introducing-advanced-matter-bridging/), and its [M100 developer page](https://opendoc.aqara.com/en/docs/AqaraDevice/Hub-M100.html) lists Advanced Matter Bridging. This supports the proposed mapping, but is not a capture from this user's M100.

The actual endpoint, labels, clusters, pulse duration and repeated-press behavior remain unknown. Discovery must enumerate descriptors, then observe the explicitly configured G400 press Signal while separately testing motion/person detection. An occupancy signal that stays active across multiple presses cannot reveal each press through rising edges alone. Debounce cannot recover missing transitions.

## Local inspection

Composer Pro and its shared 4.0.0 files are installed. Their presence does not establish the CORE 1 OS version. No standalone SDK manual was found in the inspected Control4 directories. Installed reference drivers confirmed XML action conventions and `LUA_ACTION` dispatch. A pre-existing `aqara_g400_doorbell_alpha.c4z` was inspected read-only: it is a candidate IPv4 multicast diagnostic, not a Matter controller. It was neither overwritten nor installed by this work.

The included driver was tested using the installed Windows Lua 5.1 DLL with mocked C4 APIs. This validates Lua syntax and selected behavior, not Director integration, CORE networking, crypto, or Composer import.

## Evidence needed to validate our native implementation

1. Run the runtime probe on CORE 1; record Director version and crypto results.
2. Demonstrate binary IPv6 UDP round-trip, link-local scope handling and recovery after address changes. The supplied echo probe covers only a configured unicast destination.
3. Verify mDNS discovery of `_matterc._udp` and `_matter._tcp`, including IPv6 interface/scope and multicast reception. An operational DNS-SD service label ending in `_tcp` does not remove Matter's UDP requirements.
4. Prove AES-CCM with known vectors, altered-tag rejection and Matter-sized nonces; prove P-256 operations and a supported SPAKE2+ path.
5. Verify encrypted persistence after Director restart, power cycle and driver update; profile Director latency.
6. Complete M100 multi-admin commissioning and descriptor/Signal captures.

These checks validate our implementation independently of the commercial precedent. The SPIKE's presence-only probes cannot establish protocol correctness automatically.

## Smallest proposed fallback if native implementation encounters a demonstrated blocker

Use one local process based on [matter.js](https://github.com/matter-js/matter.js) on an existing always-on computer or NAS with working LAN IPv6. Keep Matter credentials there. It commissions the M100, discovers endpoints and forwards authenticated signal reports to the Control4 driver. Control4 retains edge detection, debounce, status and the native programming event. Home Assistant, MQTT, Node-RED and cloud automation are not architectural requirements.

This is the smallest proposed component count, not a measured memory footprint. The process, service installation and live driver transport are not implemented in this spike. See [reuse research](docs/REUSE.md) and the [proposed interface](docs/HELPER_INTERFACE.md).
