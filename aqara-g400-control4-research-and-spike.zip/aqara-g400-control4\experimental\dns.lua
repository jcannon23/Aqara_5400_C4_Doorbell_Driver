-- Bounded read-only DNS codec for a discovery spike. RFC 1035 / RFC 6762.
local DNS={}
local function u16(n) return string.char(math.floor(n/256)%256,n%256) end
local function wireName(name)
  local out,total={},1
  for label in name:gmatch('[^.]+') do
    assert(#label<=63 and #label>0,'label length')
    total=total+#label+1; assert(total<=255,'name length')
    out[#out+1]=string.char(#label)..label
  end
  return table.concat(out)..'\0'
end
function DNS.query(id,name,kind)
  return u16(id)..u16(0)..u16(1)..u16(0)..u16(0)..u16(0)..wireName(name)..u16(kind)..u16(1)
end
function DNS.parse(packet)
  local ok,result=pcall(function()
    assert(type(packet)=='string' and #packet>=12 and #packet<=4096,'size')
    local function number(pos,width)
      assert(pos>=1 and pos+width-1<=#packet,'truncated')
      local n=0
      for i=pos,pos+width-1 do n=n*256+packet:byte(i) end
      return n
    end
    local function name(pos)
      local out,visited,nextPos,total={}, {},nil,1
      for _=1,128 do
        assert(not visited[pos],'pointer cycle'); visited[pos]=true
        local len=number(pos,1)
        if len==0 then return table.concat(out,'.'):lower(),nextPos or pos+1 end
        if len>=192 then
          nextPos=nextPos or pos+2
          pos=(len-192)*256+number(pos+1,1)+1
          assert(pos>=1 and pos<=#packet,'pointer range')
        else
          assert(len<=63,'invalid label')
          number(pos+len,1)
          total=total+len+1; assert(total<=255,'name length')
          out[#out+1]=packet:sub(pos+1,pos+len)
          pos=pos+len+1
        end
      end
      error('name depth')
    end
    local flags=number(3,2)
    assert(flags>=32768 and math.floor(flags/2048)%16==0 and flags%16==0,'not successful response')
    assert(math.floor(flags/512)%2==0,'truncated response')
    local questions=number(5,2)
    local count=number(7,2)+number(9,2)+number(11,2)
    assert(questions<=32 and count<=96,'record limit')
    local pos=13
    for _=1,questions do local ignored; ignored,pos=name(pos); number(pos,4); pos=pos+4 end
    local records={}
    for _=1,count do
      local owner; owner,pos=name(pos)
      local kind,class,ttl,length=number(pos,2),number(pos+2,2),number(pos+4,4),number(pos+8,2)
      pos=pos+10
      local stop=pos+length
      assert(stop<=#packet+1,'rdata bounds')
      local record={name=owner,kind=kind,class=class%32768,ttl=ttl}
      if kind==12 then
        local after; record.target,after=name(pos); assert(after==stop,'PTR length')
      elseif kind==33 then
        assert(length>=7,'SRV length'); record.port=number(pos+4,2)
        local after; record.target,after=name(pos+6); assert(after==stop,'SRV target length')
      elseif kind==16 then
        local p=pos; record.txt={}
        while p<stop do
          local len=number(p,1); p=p+1; assert(p+len<=stop,'TXT length')
          record.txt[#record.txt+1]=packet:sub(p,p+len-1); p=p+len
        end
      elseif kind==28 then
        assert(length==16,'AAAA length'); local groups={}
        for p=pos,pos+15,2 do groups[#groups+1]=string.format('%x',number(p,2)) end
        record.address=table.concat(groups,':')
      elseif kind==1 then
        assert(length==4,'A length'); local bytes={}
        for p=pos,pos+3 do bytes[#bytes+1]=tostring(number(p,1)) end
        record.address=table.concat(bytes,'.')
      end
      records[#records+1]=record; pos=stop
    end
    return {id=number(1,2),records=records}
  end)
  if not ok then return nil,'invalid or unsupported DNS response' end
  return result
end
return DNS
