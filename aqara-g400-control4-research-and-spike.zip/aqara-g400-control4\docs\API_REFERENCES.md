# Implementation references

All C4 calls in the spike were checked against official documentation. No Matter API is invented.

| Code area | Official reference |
|---|---|
| Event registration and firing | [AddEvent / FireEventByID](https://snap-one.github.io/docs-driverworks-api/#addevent) |
| Actions and LUA_ACTION dispatch | [ExecuteCommand](https://snap-one.github.io/docs-driverworks-api/#executecommand) |
| Property updates | [UpdateProperty](https://snap-one.github.io/docs-driverworks-api/#updateproperty) |
| Timer lifecycle | [SetTimer](https://snap-one.github.io/docs-driverworks-api/#settimer) |
| Version and crypto probes | [GetVersionInfo](https://snap-one.github.io/docs-driverworks-api/#getversioninfo), [Hash](https://snap-one.github.io/docs-driverworks-api/#hash), [HMAC](https://snap-one.github.io/docs-driverworks-api/#hmac), [GetSupportedCiphers](https://snap-one.github.io/docs-driverworks-api/#getsupportedciphers), [Lua OpenSSL](https://snap-one.github.io/docs-driverworks-api/#lua-openssl-interface) |
| Persistence canary | [PersistSetValue](https://snap-one.github.io/docs-driverworks-api/#persistsetvalue), [PersistGetValue](https://snap-one.github.io/docs-driverworks-api/#persistgetvalue) |
| Echo probe | [CreateNetworkConnection](https://snap-one.github.io/docs-driverworks-api/#createnetworkconnection), [NetConnect](https://snap-one.github.io/docs-driverworks-api/#netconnect), [NetDisconnect](https://snap-one.github.io/docs-driverworks-api/#netdisconnect), [SendToNetwork](https://snap-one.github.io/docs-driverworks-api/#sendtonetwork), [ReceivedFromNetwork](https://snap-one.github.io/docs-driverworks-api/#receivedfromnetwork), [UUID](https://snap-one.github.io/docs-driverworks-api/#uuid) |

The documented networking signatures do not themselves prove IPv6 support. OpenSSL probing only loads the documented module and checks selected members; it does not assert those members implement all Matter requirements.

The installed Control4 Vestibule reference driver also confirms XML action/command fields and LUA_ACTION routing. No code from that driver was copied.
