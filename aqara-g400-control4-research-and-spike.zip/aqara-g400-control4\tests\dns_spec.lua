local DNS=dofile('experimental/dns.lua')
local checks=0
local function check(v) assert(v); checks=checks+1 end
local function n(v) return string.char(math.floor(v/256)%256,v%256) end
local function name(s) local o={} for l in s:gmatch('[^.]+') do o[#o+1]=string.char(#l)..l end return table.concat(o)..'\0' end
local function header(count) return n(41990)..n(0x8400)..n(0)..n(count)..n(0)..n(0) end
local function rr(owner,kind,data)
  return name(owner)..n(kind)..n(1)..'\0\0\0\120'..n(#data)..data
end
local service='_matterc._udp.local'
local instance='example.'..service
local host='bridge.local'
local packet=header(5)..rr(service,12,name(instance))..
 rr(instance,33,n(0)..n(0)..n(5540)..name(host))..
 rr(instance,16,string.char(10)..'DN=Example')..
 rr(host,28,string.rep('\0',15)..'\1')..rr(host,1,string.char(192,168,1,2))
local r=assert(DNS.parse(packet))
check(r.id==41990 and #r.records==5)
check(r.records[1].target==instance)
check(r.records[2].port==5540 and r.records[2].target==host)
check(r.records[3].txt[1]=='DN=Example')
check(r.records[4].address=='0:0:0:0:0:0:0:1')
check(r.records[5].address=='192.168.1.2')
for i=0,#packet-1 do check(DNS.parse(packet:sub(1,i))==nil) end
-- Pointer to itself, out-of-range pointer and unsupported label type.
check(DNS.parse(header(1)..'\192\12')==nil)
check(DNS.parse(header(1)..'\255\255')==nil)
check(DNS.parse(header(1)..'\64')==nil)
local owner=name(service)
local compressed=header(1)..owner..n(12)..n(1)..'\0\0\0\120'..n(2)..'\192\12'
check(assert(DNS.parse(compressed)).records[1].target==service)
check(DNS.parse(rr(service,1,'bad'))==nil)
check(DNS.parse(header(1)..rr(service,16,'\5ab'))==nil)
check(DNS.parse(header(1)..rr(service,28,'bad'))==nil)
check(DNS.parse(header(1)..rr(service,1,'bad'))==nil)
check(DNS.parse(header(97))==nil)
check(DNS.parse(string.rep('x',4097))==nil)
local query=DNS.query(41990,service,12)
check(query==n(41990)..n(0)..n(1)..n(0)..n(0)..n(0)..name(service)..n(12)..n(1))
print('PASS: '..checks..' DNS assertions, including all fixture truncations.')
