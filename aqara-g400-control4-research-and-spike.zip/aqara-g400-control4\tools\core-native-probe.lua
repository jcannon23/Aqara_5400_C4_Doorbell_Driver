-- Paste this entire file into the feasibility driver's Composer Lua Command pane.
-- OS 4.0 target. No network, persistence, pairing, or doorbell events.
-- Temporary keys remain local to this invocation and are never printed/exported.
do
  local prefix = '[Aqara Native Probe v2] '
  local function say(text) print(prefix .. text) end
  local function unhex(text)
    return (text:gsub('%x%x', function(pair) return string.char(tonumber(pair, 16)) end))
  end
  local function tick()
    local ok, value = pcall(function() return C4:GetTickCount() end)
    return ok and type(value) == 'number' and value or nil
  end
  say('BEGIN - experimental runtime tests, not Matter validation')
  local versionOK, version = pcall(function() return C4:GetVersionInfo() end)
  say('Director: ' .. tostring(versionOK and type(version) == 'table' and version.version or 'unavailable'))
  local ok, ssl = pcall(require, 'openssl')
  if not ok or type(ssl) ~= 'table' then
    say('OpenSSL: UNAVAILABLE'); say('END'); return
  end
  local tests = {
    {'random API smoke check (not entropy certification)', function()
      local a, b = ssl.random(32), ssl.random(32)
      return type(a) == 'string' and type(b) == 'string' and #a == 32 and #b == 32 and a ~= b
    end},
    {'AES-128-ECB single-block known-answer, padding disabled', function()
      local key = unhex('000102030405060708090a0b0c0d0e0f')
      local plaintext = unhex('00112233445566778899aabbccddeeff')
      local output = ssl.cipher.encrypt('aes-128-ecb', plaintext, key, nil, false)
      return output == unhex('69c4e0d86a7b0430d8cdb78070b4c55a')
    end},
    {'P-256 ECDH shared-secret agreement', function()
      local a = assert(ssl.pkey.new('ec', 'prime256v1'))
      local b = assert(ssl.pkey.new('ec', 'prime256v1'))
      local ab = a:derive(assert(ssl.pkey.get_public(b)))
      local ba = b:derive(assert(ssl.pkey.get_public(a)))
      return type(ab) == 'string' and #ab == 32 and ab == ba
    end},
    {'P-256 ECDSA SHA256 round-trip and altered-message rejection', function()
      local key = assert(ssl.pkey.new('ec', 'prime256v1'))
      local public = assert(ssl.pkey.get_public(key))
      local signature = assert(key:sign('aqara-probe-message', 'sha256'))
      if public:verify('aqara-probe-message', signature, 'sha256') ~= true then return false end
      local verified, result = pcall(function()
        return public:verify('aqara-probe-altered', signature, 'sha256')
      end)
      -- An exception is inconclusive: require an explicit invalid result.
      return verified and (result == false or result == nil)
    end},
    {'BN modular arithmetic at P-256 field size', function()
      local bn = ssl.bn
      local p = bn.number('XFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF')
      local two = bn.number(2)
      local inverse = bn.invmod(two, p)
      return bn.mulmod(two, inverse, p):isone() and bn.mulmod(p - 1, p - 1, p):isone()
    end},
  }
  local index = 0
  local function step()
    index = index + 1
    local test = tests[index]
    if not test then
      say('AES-CCM, SPAKE2+, IPv6 and commissioning: NOT TESTED')
      say('END - share these labeled results; no key material is included')
      return
    end
    local start = tick()
    local ran, passed = pcall(test[2])
    local finish = tick()
    local elapsed = start and finish and finish >= start and ('; elapsed_ms=' .. tostring(finish-start)) or ''
    -- Do not print raw errors: runtime error strings may contain unexpected data.
    say(test[1] .. ': ' .. (ran and passed == true and 'PASS' or (ran and 'FAIL' or 'API ERROR / UNSUPPORTED')) .. elapsed)
    if index < #tests then
      local scheduled, timer = pcall(function() return C4:SetTimer(100, step) end)
      if not scheduled or not timer then say('STOP: timer unavailable'); say('END') end
    else
      step()
    end
  end
  -- Yield between tests. Each individual native call is synchronous; elapsed
  -- time is reported so actual controller latency can be assessed.
  step()
end
