# Existing repositories worth reusing

Inspected 2026-09-26 via GitHub source, README and repository metadata. No reusable open-source Control4 Matter controller was found in the searches performed. The user subsequently identified the [Solidified Systems commercial native Matter driver](https://drivercentral.io/platforms/control4-drivers/matter). This is important feasibility evidence; it is not a GitHub source dependency. Its M100 virtual Signal compatibility and implementation details remain unverified.

| Repository | Reuse opportunity | Limitation |
|---|---|---|
| [matter-js/matter.js](https://github.com/matter-js/matter.js) | Preferred foundation for a small dedicated controller helper: Matter protocol, commissioning, sessions, storage abstractions and cluster access | JavaScript/TypeScript runtime and networking required; cannot import into DriverWorks Lua |
| [matter-js/matterjs-server](https://github.com/matter-js/matterjs-server) | Ready server with WebSocket controller interface and diagnostic dashboard; usable independently of Home Assistant | README currently labels it beta; larger scope than this doorbell integration |
| [project-chip/connectedhomeip](https://github.com/project-chip/connectedhomeip) | Official SDK, protocol reference, test vectors and chip-tool for commissioning/endpoint exploration | C++/platform build requirements; not a Lua driver dependency |
| [matter-js/python-matter-server](https://github.com/matter-js/python-matter-server) | Prior server implementation and reference architecture | Archived at inspection; avoid as the default foundation for new work |
| [control4/drivers-driverpackager](https://github.com/control4/drivers-driverpackager) | Official `.c4z` packaging conventions | Archived tooling; no Matter implementation |

The first two repositories report Apache-2.0 licensing and active, unarchived status. Pin and test an exact released dependency version before implementing a helper; current branches and examples can change. No third-party implementation source has been copied into the delivered driver.

The [matter.js controller example](https://github.com/matter-js/matter.js/blob/main/examples/controller/README.md) explicitly describes its low-level example as development/debugging material and warns against using that example unchanged in production. Reuse the library and supported API, not a pasted demo.

The [Matter Server WebSocket protocol](https://github.com/matter-js/matterjs-server/blob/main/docs/websockets_api.md) exposes commissioning commands and node updates. Its table marks `subscribe_attribute` as a stub because subscriptions are handled internally. An adapter must consume actual node/attribute updates; it must not assume that named command establishes a custom subscription.

Recommendation: investigate the native commercial precedent and CORE 1 capabilities first. CHIP tooling can assist hardware investigation; if a helper ultimately proves necessary, matter.js is the preferred dedicated foundation. Matter Server is an alternative if ready commissioning/discovery tooling is more valuable than minimizing process scope. Neither option has been tested with this M100 yet.
