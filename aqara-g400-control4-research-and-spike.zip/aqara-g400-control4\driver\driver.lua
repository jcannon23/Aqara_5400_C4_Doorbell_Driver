-- Feasibility spike only. No Matter controller or live doorbell transport.
-- API references: docs/API_REFERENCES.md. Lua 5.1 compatible.
local EVENT = 1
local BINDING = 6991
local CANARY_KEY = 'aqara_g400_spike_canary_v1'
local CANARY = 'aqara-g400-persistence-check-v1'
local ready, active, debounceTimer = false, nil, nil
local probe, probeTimer, sendTimer

local function update(name, value)
  C4:UpdateProperty(name, tostring(value or ''))
end

local function log(level, message)
  if level == 'Error' or Properties['Debug Logging'] ~= 'Off' then
    print('[Aqara G400 Matter] [' .. level .. '] ' .. message)
  end
end

local function fail(message)
  update('Last Error', message)
  log('Error', message)
end

local function cancel(timer)
  if timer then timer:Cancel() end
end

local function emit(reason)
  C4:FireEventByID(EVENT)
  update('Last Doorbell Press', os.date('%Y-%m-%d %H:%M:%S') .. ' (' .. reason .. ')')
  log('Info', 'Doorbell Pressed: ' .. reason)
end

-- A subscription's first report is a baseline, never a new press.
-- A suppressed rising edge still consumes the edge; it is not queued to ring later.
local function signal(value)
  if type(value) ~= 'boolean' then return end
  local previous = active
  active = value
  if previous == nil or previous == value or not value then return end
  if debounceTimer then
    log('Debug', 'Duplicate activation ignored')
    return
  end
  local seconds = tonumber(Properties['Debounce Seconds']) or 3
  seconds = math.max(0, math.min(30, seconds))
  if seconds > 0 then
    debounceTimer = C4:SetTimer(seconds * 1000, function() debounceTimer = nil end)
  end
  emit('simulated signal')
end

local function stopProbe()
  cancel(probeTimer); probeTimer = nil
  cancel(sendTimer); sendTimer = nil
  local old = probe
  probe = nil
  if old then pcall(function() C4:NetDisconnect(BINDING, old.port) end) end
end

local function runtimeProbe()
  -- Only report booleans and known public metadata, never dump arbitrary objects.
  local lines = {}
  local function result(name, value)
    lines[#lines + 1] = name .. ': ' .. tostring(value)
  end
  local ok, version = pcall(function() return C4:GetVersionInfo() end)
  result('Director', ok and type(version) == 'table' and version.version or 'unavailable')
  result('Lua', _VERSION)
  for _, name in ipairs({'CreateNetworkConnection', 'NetConnect', 'SendToNetwork',
      'SetTimer', 'PersistSetValue', 'PersistGetValue', 'GetSupportedCiphers',
      'GetSupportedDigests', 'Hash', 'HMAC'}) do
    result('API ' .. name, type(C4[name]) == 'function')
  end
  local hashOK, hash = pcall(function()
    return C4:Hash('SHA256', 'abc', {return_encoding = 'HEX', data_encoding = 'NONE'})
  end)
  result('SHA256 known-answer', hashOK and type(hash) == 'string' and
    hash:lower() == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
  local hmacOK, mac = pcall(function()
    return C4:HMAC('SHA256', string.rep(string.char(11), 20), 'Hi There',
      {return_encoding = 'HEX', key_encoding = 'NONE', data_encoding = 'NONE'})
  end)
  result('HMAC-SHA256 known-answer', hmacOK and type(mac) == 'string' and
    mac:lower() == 'b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7')
  local cipherOK, ciphers = pcall(function() return C4:GetSupportedCiphers() end)
  local ccm = false
  if cipherOK and type(ciphers) == 'table' then
    for name in pairs(ciphers) do
      if type(name) == 'string' and name:upper() == 'AES-128-CCM' then ccm = true end
    end
  end
  result('C4 cipher list includes AES-128-CCM (not an AEAD test)', ccm)
  local sslOK, ssl = pcall(require, 'openssl')
  result('OpenSSL module loaded', sslOK and type(ssl) == 'table')
  if sslOK and type(ssl) == 'table' then
    for _, name in ipairs({'pkey', 'cipher', 'digest', 'hmac', 'bn', 'ec', 'x509'}) do
      result('OpenSSL surface ' .. name, ssl[name] ~= nil)
    end
  end
  result('IPv6 UDP/multicast', 'UNVERIFIED; separate echo test needed; multicast still needs packet capture')
  result('SPAKE2+/AES-CCM/CASE', 'UNVERIFIED; module presence is not protocol validation')
  update('Runtime Diagnostics', table.concat(lines, ' | '))
  for _, line in ipairs(lines) do print('[Aqara G400 Matter] [Probe] ' .. line) end
end

local function ipv6Probe()
  stopProbe()
  local address = Properties['Probe IPv6 Address'] or ''
  local port = tonumber(Properties['Probe UDP Port'])
  if not address:find(':', 1, true) or address:find('[%s%[%]]') or
      not port or port < 1024 or port > 65535 or port ~= math.floor(port) then
    fail('Set an IPv6 literal (no brackets) and UDP port 1024-65535 for your echo responder.')
    return
  end
  local uuidOK, uuid = pcall(function() return C4:UUID('RANDOM') end)
  if not uuidOK or type(uuid) ~= 'string' then
    fail('Unable to create probe identifier.')
    return
  end
  probe = {port = port, payload = 'AQARA-SPIKE:' .. uuid .. '\0\255'}
  update('IPv6 Probe Result', 'Waiting for exact binary echo')
  local ok = pcall(function()
    C4:CreateNetworkConnection(BINDING, address, 'UDP')
    C4:NetConnect(BINDING, port, 'UDP')
    -- Delayed send avoids assuming UDP delivers a network-connected callback.
    sendTimer = C4:SetTimer(500, function()
      sendTimer = nil
      if probe then
        local sent = pcall(function() C4:SendToNetwork(BINDING, probe.port, probe.payload) end)
        if not sent then
          stopProbe()
          update('IPv6 Probe Result', 'Send API failed; IPv6 support remains unverified')
        end
      end
    end)
    probeTimer = C4:SetTimer(5000, function()
      probeTimer = nil
      stopProbe()
      update('IPv6 Probe Result', 'Timeout; check responder, firewall, route and runtime support')
    end)
  end)
  if not ok then
    stopProbe()
    update('IPv6 Probe Result', 'Network API failed; IPv6 support remains unverified')
  end
end

function ReceivedFromNetwork(binding, port, data)
  if probe and binding == BINDING and port == probe.port and data == probe.payload then
    stopProbe()
    update('IPv6 Probe Result', 'PASS: exact binary UDP echo; multicast and Matter are NOT validated')
  end
end

function OnDriverInit()
  -- No networking, timers, or events during early initialization.
end

function OnDriverLateInit()
  cancel(debounceTimer); debounceTimer = nil
  stopProbe()
  active = nil
  local added = C4:AddEvent(EVENT, 'Doorbell Pressed', 'When the NAME doorbell is pressed', 1)
  ready = added == true
  update('Status', 'Feasibility spike - Matter not implemented')
  update('Last Error', '')
  update('IPv6 Probe Result', 'Not run')
  local ok, value = pcall(function() return C4:PersistGetValue(CANARY_KEY, true) end)
  update('Persistence Check', ok and value == CANARY and 'Canary recovered; confirm after restart' or 'No verified canary')
  if not ready then fail('Unable to register Doorbell Pressed event.') end
end

function OnDriverDestroyed()
  ready = false
  cancel(debounceTimer); debounceTimer = nil
  stopProbe()
end

function ExecuteCommand(command, params)
  if command == 'LUA_ACTION' then command = params and params.ACTION end
  if not ready then fail('Driver event is not initialized.'); return end
  if command == 'TEST_EVENT' or command == 'Test Doorbell Event' then
    -- Deliberately bypass signal state/debounce to test Composer programming.
    emit('manual test')
  elseif command == 'SIMULATE_ACTIVE' or command == 'Simulate Signal Active' then
    if Properties['Debug Logging'] == 'Off' then fail('Enable Debug Logging to simulate signals.'); return end
    signal(true)
  elseif command == 'SIMULATE_INACTIVE' or command == 'Simulate Signal Inactive' then
    if Properties['Debug Logging'] == 'Off' then fail('Enable Debug Logging to simulate signals.'); return end
    signal(false)
  elseif command == 'RUNTIME_PROBE' or command == 'Run Runtime Probe' then
    runtimeProbe()
  elseif command == 'IPV6_PROBE' or command == 'Run IPv6 UDP Echo Probe' then
    ipv6Probe()
  elseif command == 'WRITE_CANARY' or command == 'Write Persistence Canary' then
    local ok = pcall(function() C4:PersistSetValue(CANARY_KEY, CANARY, true) end)
    update('Persistence Check', ok and 'Canary queued; restart later to verify recovery' or 'Canary write failed')
  else
    fail('Unsupported action in feasibility build.')
  end
end
