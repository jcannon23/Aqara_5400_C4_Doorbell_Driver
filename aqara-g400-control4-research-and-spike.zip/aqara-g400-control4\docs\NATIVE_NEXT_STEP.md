# Native implementation investigation, step 2

The user confirmed CORE 1 runs **Control4 OS 4.0.0**. This matches the commercial precedent's minimum. No physical-controller tests have yet been supplied.

## Findings

The public [commercial product page](https://drivercentral.io/platforms/control4-drivers/matter/) has an empty attachments section when retrieved anonymously. No publicly accessible technical manual or driver package was identified. We have not inferred its internals, purchased a license, or accessed protected source.

Upstream [Lua OpenSSL PKEY tests](https://github.com/zhaozg/lua-openssl/blob/master/test/4.pkey.lua) document EC key generation, public-key extraction, signing and derivation. Its [big-number tests](https://github.com/zhaozg/lua-openssl/blob/master/test/0.bn.lua) expose modular arithmetic. These are candidate building blocks for the Control4-supported OpenSSL wrapper, subject to the platform's modifications and installed version.

The new probe tests operations instead of only module presence. AES's [FIPS 197 example](https://csrc.nist.gov/pubs/fips/197/final) checks an exact encrypted block. Passing that would offer a possible building block for CCM composition if direct AEAD support is unavailable. The upstream [cipher wrapper source](https://github.com/zhaozg/lua-openssl/blob/master/src/cipher.c) deserves care: AEAD controls alone do not prove all CCM initialization/length semantics work. No CCM implementation is claimed here.

Passing BN arithmetic would reopen an alternative to the removed `ec` module: implementing curve formulas over native big numbers. That is not yet an acceptable production SPAKE2+ implementation. Constant-time behavior, point validation, test vectors and cooperative scheduling still need investigation. The probe does not establish any of those properties.

## Run on CORE 1

1. Use Composer connected to the CORE 1, not Virtual Director.
2. Add the supplied feasibility driver if needed, or select its existing instance.
3. In its Lua Command pane, paste the entire contents of `tools/core-native-probe.lua`, then execute once.
4. Copy the lines from `[Aqara Native Probe v2] BEGIN` through `END` back into this chat.
5. Also run the existing **Run Runtime Probe** action for the SHA256/HMAC and capability results.

The new probe makes no network requests, changes no persisted data and fires no events. It generates temporary keys but does not export or print them. It yields between tests, though each individual native crypto call is synchronous. Reported times are diagnostics, not a performance guarantee.

`API ERROR / UNSUPPORTED` can mean an API-version mismatch, not necessarily an absent primitive. Do not treat a failure as proof that native Matter is impossible. Do not paste a Matter setup code; this step does not need one.

## Decisions after results

| Result | Next implementation step |
|---|---|
| PKEY, AES and BN pass | Implement and vector-test the minimal crypto adapters, including CCM/HKDF and a vetted SPAKE2+ approach |
| BN unavailable | Investigate alternate supported primitives before selecting an arithmetic implementation |
| PKEY or AES API error | Match the installed wrapper version/API and retest |
| Crypto adapters validated | Complete binary IPv6 UDP/mDNS transport tests, then commissioning state machine |

Do not start commissioning until transport and security adapters have passed. Existing IPv6 echo tools remain available for the separate transport test.
