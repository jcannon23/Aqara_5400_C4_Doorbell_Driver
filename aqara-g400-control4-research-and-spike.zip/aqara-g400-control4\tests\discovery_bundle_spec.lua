local output,timers,sends,closed={},{},0,false
local sock={
 settimeout=function(_,v) assert(v==0); return 1 end,
 setsockname=function(_,a,p) assert(a=='*' and p==0); return 1 end,
 setoption=function(_,name,value) assert(name=='ip-multicast-ttl' and value==255); return 1 end,
 sendto=function(_,data,ip,port) assert(ip=='224.0.0.251' and port==5353); sends=sends+1; return #data end,
 receivefrom=function() return nil,'timeout' end,
 close=function() closed=true end,
}
local env=setmetatable({
 print=function(s) output[#output+1]=s end,
 require=function() return {udp4=function() return sock end} end,
 C4={SetTimer=function(_,delay,fn) timers[#timers+1]={delay=delay,fn=fn}; return {Cancel=function() end} end},
},{__index=_G})
local chunk=assert(loadfile('tools/core-discovery-probe.lua')); setfenv(chunk,env); chunk()
assert(sends==2 and not closed)
table.sort(timers,function(a,b) return a.delay<b.delay end)
for _,t in ipairs(timers) do t.fn() end
assert(closed and not env.AqaraDiscoveryRunning)
assert(table.concat(output,'\n'):find('END %- socket closed'))
print('PASS: discovery bundle timeout/cleanup and bounded query dispatch (mock network).')
