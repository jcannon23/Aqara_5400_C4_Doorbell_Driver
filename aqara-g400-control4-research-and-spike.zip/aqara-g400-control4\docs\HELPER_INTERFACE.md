# Proposed local helper interface — design only

This contract is not implemented or enabled in the supplied feasibility driver.

Flow: M100 -> Matter controller helper -> authenticated LAN stream -> Control4 event -> Announcement Agent.

One always-on process should own the Matter SDK, fabric storage, commissioning, discovery, CASE sessions and subscriptions. Use an existing host rather than adding dedicated hardware by default. Store versioned credentials in a restricted persistent directory, outside temporary/container layers. Commission through a local administration interface; do not put setup codes in command-line history or regular logs.

The Control4 driver initiates a TCP/TLS connection to the helper. Authenticate and encrypt using a validated server certificate and a separate integration credential. Certificate verification must stay enabled. Confirm the target OS's TLS API behavior before implementing this interface. Matter keys never cross this boundary.

Proposed framing: bounded newline-delimited UTF-8 JSON, maximum 4096 bytes per frame, incremental parsing with buffer limits. Use a versioned envelope and unique session identifier; monotonic sequence numbers are scoped to that authenticated session.

Example fields (illustrative, not actual discovered identifiers):

```json
{"v":1,"type":"signal","session":"opaque-session-id","seq":12,"node":"decimal-string","endpoint":7,"cluster":1030,"attribute":0,"active":true,"baseline":false}
```

Node and fabric identifiers remain strings to avoid 64-bit rounding in Lua/JavaScript numbers. Endpoint, cluster and attribute are accepted only after discovery and explicit target selection. Occupancy is decoded as its occupied bit, not arbitrary nonzero data.

Required message types: `hello`, `status`, `endpoint_inventory`, `signal`, `heartbeat`, `error`. The authenticated hello identifies the protocol version and configured node. Each new session/subscription begins with a baseline report; a baseline never rings. Disconnections invalidate the signal state. Do not replay old presses after reconnect.

Control4 rejects duplicate/out-of-order sequence numbers, unknown message versions, oversized frames, wrong targets and malformed values. It owns rising-edge detection and configurable debounce. A suppressed edge is consumed, not queued. The helper provides actual state reports and a fresh baseline after resubscription; it does not convert arbitrary traffic into presses.

Use heartbeat timeout and exponential reconnect backoff capped at 60 seconds, with jitter. Distinguish helper transport connected from Matter subscribed. A healthy TCP connection alone must not produce a `Subscribed` status. After an outage, prioritize fresh subscription state over replay. Exactly-once delivery across arbitrary power failures is not promised; avoid false delayed chimes.

Before implementing: choose host, pin the Matter library, capture M100 endpoint behavior, verify authenticated TLS transport on CORE 1 and define credential provisioning/update behavior. No helper service or firewall change was installed as part of this research.
