$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.IO.Compression
$source = Join-Path $PSScriptRoot 'driver'
$destination = Join-Path $PSScriptRoot 'build/aqara_g400_matter_spike.c4z'
[xml]$xml = Get-Content -LiteralPath (Join-Path $source 'driver.xml') -Raw
if ($xml.devicedata.config.script.file -ne 'driver.lua') { throw 'Invalid script reference' }
if ($xml.devicedata.combo -ne 'true' -or $xml.devicedata.proxies.proxy.InnerText -ne 'aqara_g400_matter_spike') { throw 'Missing combo driver identity' }
New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
$stream = [System.IO.File]::Open($destination, [System.IO.FileMode]::Create)
$zip = New-Object System.IO.Compression.ZipArchive($stream, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  foreach ($name in @('driver.xml', 'driver.lua')) {
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, (Join-Path $source $name), $name) | Out-Null
  }
} finally { $zip.Dispose(); $stream.Dispose() }
Get-FileHash -LiteralPath $destination -Algorithm SHA256
