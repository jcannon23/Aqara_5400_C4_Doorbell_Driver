-- Paste all into the feasibility driver's Composer Lua Command pane.
-- Temporary callback wrappers restore themselves after 7 seconds.
do
  if AqaraNetworkProbeRunning then print('[Aqara Net Probe v4] Already running'); return end
  local targets={
    {id=6992,label='IPv4',address='192.168.1.198'},
    {id=6993,label='IPv6',address='fdb2:736a:697e:40e7:3a7a:74c8:d9a9:c2a1'},
  }
  local port=55491
  local previousReceive,previousStatus=ReceivedFromNetwork,OnNetworkStatusChanged
  local timers={}
  local function say(s) print('[Aqara Net Probe v4] '..s) end
  local ok,nonce=pcall(function() return C4:UUID('RANDOM') end)
  if not ok or type(nonce)~='string' then say('Cannot create probe ID'); return end
  AqaraNetworkProbeRunning=true
  local function find(id) for _,t in ipairs(targets) do if t.id==id then return t end end end
  local receiveWrapper,statusWrapper
  receiveWrapper=function(id,p,data)
    local t=find(id)
    if t and p==port then
      if data==t.payload then t.passed=true; say(t.label..' PASS: exact binary echo') end
    elseif previousReceive then previousReceive(id,p,data) end
  end
  statusWrapper=function(id,p,status)
    local t=find(id)
    if t and p==port then say(t.label..' network status: '..tostring(status))
    elseif previousStatus then previousStatus(id,p,status) end
  end
  local function cleanup()
    for _,timer in ipairs(timers) do pcall(function() timer:Cancel() end) end
    for _,t in ipairs(targets) do pcall(function() C4:NetDisconnect(t.id,port) end) end
    if ReceivedFromNetwork==receiveWrapper then ReceivedFromNetwork=previousReceive end
    if OnNetworkStatusChanged==statusWrapper then OnNetworkStatusChanged=previousStatus end
    AqaraNetworkProbeRunning=nil
  end
  ReceivedFromNetwork=receiveWrapper; OnNetworkStatusChanged=statusWrapper
  say('BEGIN - dual-stack UDP comparison; no Matter traffic or doorbell events')
  local ran=pcall(function()
    -- Final cleanup is scheduled before opening sockets.
    timers[#timers+1]=assert(C4:SetTimer(7000,function()
      for _,t in ipairs(targets) do
        say(t.label..' RESULT: '..(t.passed and 'PASS' or 'NO ECHO'))
      end
      cleanup(); say('END - callbacks restored')
    end))
    for _,t in ipairs(targets) do
      t.payload='AQARA-NET4:'..t.label..':'..nonce..'\0\255'
      local opened=pcall(function()
        C4:CreateNetworkConnection(t.id,t.address,'UDP')
        C4:NetConnect(t.id,port,'UDP')
      end)
      t.opened=opened
      say(t.label..' setup call: '..(opened and 'returned (not proof of connectivity)' or 'API ERROR'))
    end
    for _,delay in ipairs({250,1000,2500}) do
      timers[#timers+1]=assert(C4:SetTimer(delay,function()
        for _,t in ipairs(targets) do
          if t.opened and not t.passed then
            local sent=pcall(function() C4:SendToNetwork(t.id,port,t.payload) end)
            say(t.label..' send call: '..(sent and 'returned' or 'API ERROR'))
          end
        end
      end))
    end
  end)
  if not ran then cleanup(); say('STOP: setup/timer failure; callbacks restored') end
end
