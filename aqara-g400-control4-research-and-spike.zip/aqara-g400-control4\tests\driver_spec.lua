-- Run from project root with Lua 5.1: lua tests/driver_spec.lua
local now, timers, events, network, saved = 0, {}, {}, {}, {}
local tests = 0
Properties = {['Debug Logging']='Off', ['Debounce Seconds']='3',
  ['Probe IPv6 Address']='fd00::2', ['Probe UDP Port']='55490'}
C4 = {}
function C4:UpdateProperty(name, value) Properties[name] = value end
function C4:AddEvent(id, name) assert(id == 1 and name == 'Doorbell Pressed'); return true end
function C4:FireEventByID(id) events[#events+1] = id end
function C4:SetTimer(delay, callback)
  local t = {at=now+delay, callback=callback}
  function t:Cancel() self.cancelled = true end
  timers[#timers+1] = t
  return t
end
function C4:PersistSetValue(key, value, encrypted) assert(encrypted); saved[key] = value end
function C4:PersistGetValue(key, encrypted) assert(encrypted); return saved[key] end
function C4:UUID() return '00000000-0000-4000-8000-000000000001' end
function C4:CreateNetworkConnection(binding, address, kind)
  network.created = {binding, address, kind}
end
function C4:NetConnect(binding, port, kind) network.connected = true end
function C4:NetDisconnect() network.connected = false end
function C4:SendToNetwork(binding, port, payload) network.sent = {binding, port, payload} end
local function advance(ms)
  local target = now + ms
  while true do
    local nextTimer
    for _, t in ipairs(timers) do
      if not t.cancelled and t.at <= target and (not nextTimer or t.at < nextTimer.at) then nextTimer=t end
    end
    if not nextTimer then break end
    now=nextTimer.at; nextTimer.cancelled=true; nextTimer.callback(nextTimer)
  end
  now=target
end
local function check(value, message) assert(value, message); tests=tests+1 end
local function action(value) ExecuteCommand('LUA_ACTION', {ACTION=value}) end
dofile('driver/driver.lua')
OnDriverInit()
check(#timers == 0 and not network.created, 'early init has no side effects')
OnDriverLateInit()
action('Test Doorbell Event')
check(#events == 1 and events[1] == 1, 'native test event')
action('Simulate Signal Inactive'); action('Simulate Signal Active')
check(#events == 1, 'simulations disabled by default')
Properties['Debug Logging']='On'
action('Simulate Signal Active')
check(#events == 1, 'initial active snapshot must not ring')
action('Simulate Signal Inactive'); action('Simulate Signal Active')
check(#events == 2, 'rising edge rings')
advance(4000); action('Simulate Signal Active')
check(#events == 2, 'held active never repeats after debounce expires')
action('Simulate Signal Inactive'); action('Simulate Signal Active')
check(#events == 3, 'rearmed activation rings')
advance(100); action('Simulate Signal Inactive'); action('Simulate Signal Active')
check(#events == 3, 'rapid second edge suppressed')
advance(3000); action('Simulate Signal Active')
check(#events == 3, 'suppressed edge does not become delayed ring')
action('Simulate Signal Inactive'); action('Simulate Signal Active')
check(#events == 4, 'later legitimate press works')
action('TEST_EVENT')
check(#events == 5, 'manual test bypasses debounce')
action('WRITE_CANARY'); OnDriverLateInit()
check(Properties['Persistence Check']:find('recovered'), 'canary read after simulated restart')
action('SIMULATE_ACTIVE')
check(#events == 5, 'restart active snapshot suppressed')
action('IPV6_PROBE'); advance(500)
check(network.sent and #network.sent[3] > 0, 'probe sends payload')
ReceivedFromNetwork(6991,55490,'wrong')
check(Properties['IPv6 Probe Result']:find('Waiting'), 'unrelated packet ignored')
ReceivedFromNetwork(6991,55490,network.sent[3])
check(Properties['IPv6 Probe Result']:find('PASS') and not network.connected, 'exact binary echo accepted and socket closed')
advance(6000)
check(Properties['IPv6 Probe Result']:find('PASS'), 'success cancels timeout')
check(#events == 5, 'network diagnostics never ring doorbell')
action('IPV6_PROBE'); advance(6000)
check(Properties['IPv6 Probe Result']:find('Timeout') and not network.connected, 'timeout closes socket')
Properties['Probe IPv6 Address']='192.0.2.1'; action('IPV6_PROBE')
check(Properties['Last Error']:find('IPv6 literal'), 'reject IPv4 probe address')
action('RUNTIME_PROBE')
check(Properties['Runtime Diagnostics']:find('UNVERIFIED'), 'missing APIs reported without crashing')
Properties['Debounce Seconds']='0'
action('SIMULATE_INACTIVE'); action('SIMULATE_ACTIVE'); action('SIMULATE_INACTIVE'); action('SIMULATE_ACTIVE')
check(#events == 7, 'zero debounce permits distinct edges')
OnDriverDestroyed(); action('TEST_EVENT')
check(#events == 7, 'destroyed driver cannot emit')
print('PASS: ' .. tests .. ' behavioral assertions (mock C4; no hardware validation).')
