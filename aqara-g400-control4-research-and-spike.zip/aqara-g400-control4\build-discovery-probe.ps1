$ErrorActionPreference='Stop'
$module=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'experimental/dns.lua') -Raw
$body=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'experimental/mdns_probe_body.lua') -Raw
$bundle="-- Generated standalone read-only discovery probe. Paste all into Composer Lua Command.`n"+
 "do`nlocal DNS=(function()`n"+$module+"`nend)()`n"+$body+"`nend`n"
[System.IO.File]::WriteAllText((Join-Path $PSScriptRoot 'tools/core-discovery-probe.lua'),$bundle,(New-Object System.Text.UTF8Encoding($false)))
